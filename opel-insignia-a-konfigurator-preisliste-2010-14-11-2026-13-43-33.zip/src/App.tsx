import { useEffect, useMemo, useState } from 'react';
import { Header } from './components/Header';
import { PriceListModal } from './components/PriceListModal';
import { StepExterieurInterieur } from './components/StepExterieurInterieur';
import { StepKarosserieTrim } from './components/StepKarosserieTrim';
import { StepMotor } from './components/StepMotor';
import { StepSonderausstattung } from './components/StepSonderausstattung';
import { StepZusammenfassung } from './components/StepZusammenfassung';
import { StudioStage } from './components/StudioStage';
import { CONFIG_OPTIONS } from './data/insignia2010';
import {
  BodyStyleId,
  ConfigStep,
  ConfigurationState,
  PriceMode,
  SavedBuild,
  StudioView,
  TrimId,
} from './types/configurator';
import {
  createInitialConfig,
  evaluateConfiguration,
  getDefaultInfotainmentForTrim,
  sanitizeConfiguration,
} from './utils/configEngine';
import { AlertCircle, Info, X } from 'lucide-react';

const SAVED_BUILDS_STORAGE_KEY = 'opel_insignia_2010_saved_builds_v1';

const MOBILE_STEPS: { id: ConfigStep; label: string }[] = [
  { id: 'karosserie', label: '1. Linie' },
  { id: 'motor', label: '2. Motor' },
  { id: 'exterieur', label: '3. Design' },
  { id: 'extras', label: '4. Extras' },
  { id: 'zusammenfassung', label: '5. Bilanz' },
];

export default function App() {
  const [config, setConfig] = useState<ConfigurationState>(createInitialConfig);
  const [activeStep, setActiveStep] = useState<ConfigStep>('karosserie');
  const [priceMode, setPriceMode] = useState<PriceMode>('brutto');
  const [studioView, setStudioView] = useState<StudioView>('exterior');
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [pdfOpen, setPdfOpen] = useState(false);

  const [savedBuilds, setSavedBuilds] = useState<SavedBuild[]>(() => {
    try {
      const raw = localStorage.getItem(SAVED_BUILDS_STORAGE_KEY);
      return raw ? (JSON.parse(raw) as SavedBuild[]) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(SAVED_BUILDS_STORAGE_KEY, JSON.stringify(savedBuilds));
    } catch {
      // Ignore storage quota errors
    }
  }, [savedBuilds]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => setToastMessage(null), 5000);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  const updateConfig = (updater: (prev: ConfigurationState) => ConfigurationState) => {
    setConfig((prev) => sanitizeConfiguration(updater(prev), showToast));
  };

  const evaluated = useMemo(() => evaluateConfiguration(config, updateConfig), [config]);

  const handleSelectStep = (step: ConfigStep) => {
    setActiveStep(step);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectBodyStyle = (bodyStyle: BodyStyleId) => {
    updateConfig((prev) => ({ ...prev, bodyStyle }));
    if (studioView === 'interior') setStudioView('exterior');
  };

  const handleSelectTrim = (trim: TrimId) => {
    updateConfig((prev) => ({
      ...prev,
      trim,
      infotainmentId: getDefaultInfotainmentForTrim(trim),
    }));
  };

  const handleSelectEngine = (engineId: string, switchTrimTo?: TrimId) => {
    updateConfig((prev) => ({
      ...prev,
      engineId,
      trim: switchTrimTo ?? prev.trim,
      infotainmentId: switchTrimTo
        ? getDefaultInfotainmentForTrim(switchTrimTo)
        : prev.infotainmentId,
    }));
  };

  const handleToggleOption = (optionId: string) => {
    updateConfig((prev) => {
      const exists = prev.selectedOptionIds.includes(optionId);
      if (exists) {
        return {
          ...prev,
          selectedOptionIds: prev.selectedOptionIds.filter((id) => id !== optionId),
        };
      }
      const opt = CONFIG_OPTIONS.find((o) => o.id === optionId);
      let nextIds = [...prev.selectedOptionIds];
      if (opt?.mutuallyExclusiveGroup) {
        const groupIds = CONFIG_OPTIONS.filter(
          (o) => o.mutuallyExclusiveGroup === opt.mutuallyExclusiveGroup
        ).map((o) => o.id);
        nextIds = nextIds.filter((id) => !groupIds.includes(id));
      }
      nextIds.push(optionId);
      return { ...prev, selectedOptionIds: nextIds };
    });
  };

  const handleToggleAccessory = (accId: string) => {
    updateConfig((prev) => {
      const exists = prev.selectedAccessoryIds.includes(accId);
      return {
        ...prev,
        selectedAccessoryIds: exists
          ? prev.selectedAccessoryIds.filter((id) => id !== accId)
          : [...prev.selectedAccessoryIds, accId],
      };
    });
  };

  const handleSaveBuild = (name: string) => {
    const newBuild: SavedBuild = {
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name,
      createdAt: new Date().toISOString(),
      totalBrutto: evaluated.totalBrutto,
      totalNetto: evaluated.totalNetto,
      summaryTitle: `${evaluated.body.shortName} · ${evaluated.trim.name} · ${evaluated.engine.name}`,
      config,
    };
    setSavedBuilds((prev) => [newBuild, ...prev]);
    showToast(`Konfiguration „${name}“ gespeichert.`);
  };

  const handleLoadBuild = (build: SavedBuild) => {
    setConfig(sanitizeConfiguration(build.config));
    showToast(`Konfiguration „${build.name}“ geladen.`);
  };

  const handleDeleteBuild = (id: string) => {
    setSavedBuilds((prev) => prev.filter((b) => b.id !== id));
  };

  const handleReset = () => {
    setConfig(createInitialConfig());
    setActiveStep('karosserie');
    setStudioView('exterior');
    showToast('Konfiguration auf Werksvorgabe zurückgesetzt.');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F7F7F5] text-[#141517] print:min-h-0 print:bg-white">
      <Header activeStep={activeStep} onSelectStep={handleSelectStep} />

      {/* Mobile Step Strip */}
      <div className="no-print md:hidden border-b border-[#E4E5E7] bg-white px-3 py-2 overflow-x-auto">
        <div className="flex items-center gap-1.5">
          {MOBILE_STEPS.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => handleSelectStep(s.id)}
              className={`rounded-md px-2.5 py-1 text-xs font-medium whitespace-nowrap shrink-0 transition-colors ${
                activeStep === s.id
                  ? 'bg-[#141517] text-white'
                  : 'bg-[#F2F3F0] text-[#5C6068]'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main 2-Column Configurator Workspace */}
      <main className="mx-auto w-full max-w-[1440px] flex-1 px-4 py-6 sm:px-6 lg:px-8">
        {/* Auto-adjustment Toast */}
        {toastMessage && (
          <div
            role="status"
            className="no-print mb-5 flex items-center justify-between gap-3 rounded-xl border border-[#E4E5E7] bg-white px-4 py-3 text-xs text-[#141517] shadow-xs"
          >
            <div className="flex items-center gap-2">
              <Info className="h-4 w-4 text-[#D99B00] shrink-0" />
              <span>{toastMessage}</span>
            </div>
            <button
              type="button"
              onClick={() => setToastMessage(null)}
              aria-label="Hinweis schließen"
              className="text-[#5C6068] hover:text-[#141517]"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start print:block">
          {/* Left Sticky Studio Stage */}
          <div className="no-print lg:col-span-5 xl:col-span-5">
            <StudioStage
              body={evaluated.body}
              trim={evaluated.trim}
              engine={evaluated.engine}
              paint={evaluated.paint}
              seatPkg={evaluated.seatPkg}
              interiorColor={config.interiorColor}
              wheel={evaluated.wheel}
              totalBrutto={evaluated.totalBrutto}
              totalNetto={evaluated.totalNetto}
              effectiveTrunkL={evaluated.effectiveTrunkL}
              trunkReduction={evaluated.trunkReduction}
              priceMode={priceMode}
              onChangePriceMode={setPriceMode}
              studioView={studioView}
              onChangeStudioView={setStudioView}
              perf={evaluated.perf}
              onOpenPriceListPdf={() => setPdfOpen(true)}
            />
          </div>

          {/* Right Configuration Panel */}
          <div className="lg:col-span-7 xl:col-span-7 flex flex-col gap-5 print:w-full print:block">
            {/* Active Dependency Notices */}
            {evaluated.notices.length > 0 && (
              <div className="no-print space-y-2">
                {evaluated.notices.map((notice) => (
                  <div
                    key={notice.id}
                    className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-[#FDE68A] bg-[#FFFBEB] px-4 py-3 text-xs text-[#92400E]"
                  >
                    <div className="flex items-start gap-2">
                      <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-[#B45309]" />
                      <span>{notice.message}</span>
                    </div>
                    {notice.actionLabel && notice.onFix && (
                      <button
                        type="button"
                        onClick={notice.onFix}
                        className="rounded-lg bg-[#141517] px-3 py-1.5 text-xs font-semibold text-white hover:bg-[#2A2D32] transition-colors whitespace-nowrap shrink-0"
                      >
                        {notice.actionLabel}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}

            {activeStep === 'karosserie' && (
              <StepKarosserieTrim
                bodyStyle={config.bodyStyle}
                trim={config.trim}
                priceMode={priceMode}
                onSelectBodyStyle={handleSelectBodyStyle}
                onSelectTrim={handleSelectTrim}
                onNext={() => handleSelectStep('motor')}
              />
            )}

            {activeStep === 'motor' && (
              <StepMotor
                bodyStyle={config.bodyStyle}
                trim={config.trim}
                engineId={config.engineId}
                priceMode={priceMode}
                onSelectEngine={handleSelectEngine}
                onNext={() => handleSelectStep('exterieur')}
              />
            )}

            {activeStep === 'exterieur' && (
              <StepExterieurInterieur
                state={config}
                priceMode={priceMode}
                onSelectPaint={(paintId) => updateConfig((p) => ({ ...p, paintId }))}
                onSelectSeatPackage={(seatPackageId) =>
                  updateConfig((p) => ({ ...p, seatPackageId }))
                }
                onSelectInteriorColor={(interiorColor) =>
                  updateConfig((p) => ({ ...p, interiorColor }))
                }
                onSelectDecor={(decorId) => updateConfig((p) => ({ ...p, decorId }))}
                onSelectWheel={(wheelId) => updateConfig((p) => ({ ...p, wheelId }))}
                onNext={() => handleSelectStep('extras')}
              />
            )}

            {activeStep === 'extras' && (
              <StepSonderausstattung
                state={config}
                priceMode={priceMode}
                onToggleOption={handleToggleOption}
                onSelectInfotainment={(infotainmentId) =>
                  updateConfig((p) => ({ ...p, infotainmentId }))
                }
                onSelectPhonePrep={(phonePrepId) =>
                  updateConfig((p) => ({ ...p, phonePrepId }))
                }
                onSelectWarranty={(warrantyId) => updateConfig((p) => ({ ...p, warrantyId }))}
                onToggleAccessory={handleToggleAccessory}
                onNext={() => handleSelectStep('zusammenfassung')}
              />
            )}

            {activeStep === 'zusammenfassung' && (
              <StepZusammenfassung
                state={config}
                body={evaluated.body}
                trim={evaluated.trim}
                engine={evaluated.engine}
                paint={evaluated.paint}
                seatPkg={evaluated.seatPkg}
                wheel={evaluated.wheel}
                basePrice={evaluated.basePrice}
                lineItems={evaluated.lineItems}
                accessoryItems={evaluated.accessoryItems}
                totalBrutto={evaluated.totalBrutto}
                totalNetto={evaluated.totalNetto}
                vatAmount={evaluated.vatAmount}
                effectiveTrunkL={evaluated.effectiveTrunkL}
                trunkReduction={evaluated.trunkReduction}
                perf={evaluated.perf}
                savedBuilds={savedBuilds}
                onSaveBuild={handleSaveBuild}
                onLoadBuild={handleLoadBuild}
                onDeleteBuild={handleDeleteBuild}
                onReset={handleReset}
              />
            )}
          </div>
        </div>
      </main>

      <footer className="no-print border-t border-[#E4E5E7] bg-white py-5 text-xs text-[#5C6068]">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
          <div>
            Grundlage: Offizielle Preisliste OPEL Insignia &amp; Insignia Sports Tourer, Stand
            21. Juni 2010 (Best.-Nr.: 01/04030/1001) · Alle Preisangaben UVP ab Werk.
          </div>
          <button
            type="button"
            onClick={() => setPdfOpen(true)}
            className="font-medium text-[#141517] underline hover:text-[#D99B00]"
          >
            Original-Preisliste (PDF) öffnen
          </button>
        </div>
      </footer>

      <PriceListModal open={pdfOpen} onClose={() => setPdfOpen(false)} />
    </div>
  );
}
