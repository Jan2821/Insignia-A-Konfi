import {
  ACCESSORIES,
  BODY_STYLES,
  CONFIG_OPTIONS,
  ENGINES,
  INFOTAINMENT_SYSTEMS,
  PAINT_COLORS,
  PHONE_PREPS,
  SEAT_PACKAGES,
  TRIM_LINES,
  WARRANTIES,
  WHEELS,
} from '../data/insignia2010';
import {
  BodyStyleId,
  ConfigOption,
  ConfigurationState,
  EngineSpec,
  LineItem,
  PriceMode,
  TrimId,
  ValidationNotice,
} from '../types/configurator';

export function formatEuro(amount: number): string {
  const formatted = new Intl.NumberFormat('de-DE', {
    minimumFractionDigits: amount % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(amount);
  return amount % 1 === 0 ? `${formatted},– €` : `${formatted} €`;
}

export function getDefaultWheelForTrim(trim: TrimId): string {
  if (trim === 'selection') return 'STD_16';
  if (trim === 'edition') return 'STD_17_DESIGN';
  if (trim === 'sport') return 'Q02';
  return 'Q56';
}

export function getDefaultInfotainmentForTrim(trim: TrimId): 'UZZ' | 'UXW' | 'UXX' {
  return trim === 'selection' ? 'UZZ' : 'UXX';
}

export function getDefaultDecorForTrim(
  trim: TrimId,
  interiorColor: ConfigurationState['interiorColor']
): ConfigurationState['decorId'] {
  if (trim === 'selection') return 'titanium';
  if (trim === 'edition') return interiorColor === 'Beige' ? 'titanium_oliv' : 'titanium';
  if (trim === 'sport') return 'klavierlack';
  return interiorColor === 'Beige' ? 'kibo_holz' : 'kibo_holz';
}

export function createInitialConfig(): ConfigurationState {
  return {
    bodyStyle: 'limo5',
    trim: 'edition',
    engineId: '20_cdti_118',
    paintId: 'silbersee',
    seatPackageId: 'STD',
    interiorColor: 'Schwarz',
    decorId: 'titanium',
    wheelId: 'STD_17_DESIGN',
    infotainmentId: 'UXX',
    phonePrepId: null,
    warrantyId: null,
    selectedOptionIds: [],
    selectedAccessoryIds: [],
  };
}

export function getAvailableEngines(bodyStyle: BodyStyleId, trim: TrimId): EngineSpec[] {
  return ENGINES.filter((e) => Boolean(e.prices[bodyStyle]?.[trim]));
}

export function getOptionStatus(
  option: ConfigOption,
  state: ConfigurationState
): {
  available: boolean;
  includedAsSerie: boolean;
  includedInPackage: string | null;
  priceBrutto: number;
  priceNetto: number;
  reason?: string;
} {
  if (option.bodyStyles && !option.bodyStyles.includes(state.bodyStyle)) {
    return {
      available: false,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
      reason:
        option.bodyStyles.length === 1 && option.bodyStyles[0] === 'tourer'
          ? 'Nur für Sports Tourer'
          : option.bodyStyles.length === 1 && option.bodyStyles[0] === 'limo5'
          ? 'Nur für Limousine, 5-türig'
          : 'Nur für Limousine (4-/5-türig)',
    };
  }

  const trimPrice = option.prices[state.trim];
  if (trimPrice === undefined) {
    return {
      available: false,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
      reason: `Nicht für ${TRIM_LINES[state.trim].name}`,
    };
  }

  const engine = ENGINES.find((e) => e.id === state.engineId);
  const seatPkg = SEAT_PACKAGES.find((s) => s.id === state.seatPackageId);
  const hasInnovationsPaket = state.selectedOptionIds.includes('PHLC_INNO');
  const hasSportEditionPaket = state.selectedOptionIds.includes('PHLC_SPORT_EDITION');
  const hasAnyPremiumPaket = Boolean(seatPkg?.isPremiumPackage);
  const hasLeather = Boolean(seatPkg?.hasLeather);
  const hasAflPlus =
    state.trim === 'innovation' ||
    hasInnovationsPaket ||
    state.selectedOptionIds.includes('TT2');
  const hasSichtPaket =
    state.trim === 'innovation' ||
    hasInnovationsPaket ||
    state.selectedOptionIds.includes('TSQ');

  // Specific engine & trim inclusions from Preisliste
  if (option.id === 'URC') {
    if (engine?.id === '16_ecotec' || engine?.id === '20_cdti_81') {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nicht für 1.6 (85 kW) und 2.0 CDTI (81 kW)',
      };
    }
    if (engine?.id.startsWith('28_v6') || engine?.id.startsWith('20_turbo_6g_4x4') || engine?.id.startsWith('20_turbo_at_4x4')) {
      return {
        available: true,
        includedAsSerie: true,
        includedInPackage: 'Serienmäßig bei diesem Motor (4x4 / V6)',
        priceBrutto: 0,
        priceNetto: 0,
      };
    }
    if (state.selectedOptionIds.includes('G67')) {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nicht in Verb. mit Niveauregulierung (G67)',
      };
    }
  }

  if (option.id === 'G67') {
    const flexRideActive =
      state.trim === 'sport' ||
      hasInnovationsPaket ||
      state.selectedOptionIds.includes('URC') ||
      engine?.id.startsWith('28_v6') ||
      engine?.id === '20_turbo_6g_4x4' ||
      engine?.id === '20_turbo_at_4x4';
    if (flexRideActive) {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nicht in Verb. mit FlexRide Premium-Fahrwerk',
      };
    }
  }

  // Package inclusion checks
  if (hasInnovationsPaket && ['TT2', 'URC', 'UDP', 'UVT', 'TSQ', 'T96'].includes(option.id)) {
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: 'Im Innovations-Paket (PHLC) enthalten',
      priceBrutto: 0,
      priceNetto: 0,
    };
  }
  if (hasInnovationsPaket && option.id === 'UD5') {
    return {
      available: false,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
      reason: 'Parkassistent (inkl. Parkpilot) bereits im Innovations-Paket enthalten',
    };
  }

  if (hasSportEditionPaket && ['WBP', 'XK0', 'AKo'].includes(option.id)) {
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: 'Im Sport Edition-Paket (PHLC) enthalten',
      priceBrutto: 0,
      priceNetto: 0,
    };
  }

  if (seatPkg?.includesOpcInterior && option.id === 'XK0') {
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: 'Im Nappaleder Indian Summer Paket enthalten',
      priceBrutto: 0,
      priceNetto: 0,
    };
  }

  if (option.id === 'AKo' && state.bodyStyle === 'tourer' && (state.trim === 'sport' || state.trim === 'innovation')) {
    return {
      available: true,
      includedAsSerie: true,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
    };
  }

  if (option.id === 'AER' && hasLeather) {
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: 'In der Lederausstattung enthalten',
      priceBrutto: 0,
      priceNetto: 0,
    };
  }

  if (option.id === 'A6D' && seatPkg?.hasAgrPassenger) {
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: 'Im gewählten AGR-Sitzpaket enthalten',
      priceBrutto: 0,
      priceNetto: 0,
    };
  }

  if (option.id === 'PHLC_SPORT_EDITION') {
    const eligible =
      seatPkg &&
      ['PHAV_19', 'PHAV_20', 'PHAV_NAPPA_19', 'PHAV_NAPPA_20'].includes(seatPkg.id);
    if (!eligible) {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Erfordert Premium-Paket Leder (PHAV) oder Premium-Paket Nappaleder',
      };
    }
    if (state.interiorColor === 'Beige') {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nicht in Verb. mit Polster Beige',
      };
    }
    const isNappa = seatPkg.id.includes('NAPPA');
    const isST = state.bodyStyle === 'tourer';
    if (isNappa) {
      return {
        available: true,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: isST ? 690 : 830,
        priceNetto: isST ? 579.83 : 697.48,
      };
    }
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: isST ? 1050 : 1190,
      priceNetto: isST ? 882.35 : 1000.0,
    };
  }

  if (option.id === 'W7Z') {
    if (hasLeather && hasAflPlus) {
      return {
        available: true,
        includedAsSerie: false,
        includedInPackage: 'Sitzheizung (Leder) & Scheinwerfer-Reinigung (AFL+) bereits enthalten',
        priceBrutto: 0,
        priceNetto: 0,
      };
    }
    if (hasLeather && state.trim !== 'selection') {
      return {
        available: true,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 105,
        priceNetto: 88.24,
      };
    }
    if (hasAflPlus && state.trim !== 'selection') {
      return {
        available: true,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 260,
        priceNetto: 218.49,
      };
    }
  }

  if (option.id === 'AG1') {
    if (!hasSichtPaket) {
      return {
        available: true,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: hasAnyPremiumPaket ? 230 : 525,
        priceNetto: hasAnyPremiumPaket ? 193.28 : 441.18,
        reason: 'Erfordert Sicht-Paket (TSQ)',
      };
    }
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: hasAnyPremiumPaket ? 230 : 525,
      priceNetto: hasAnyPremiumPaket ? 193.28 : 441.18,
    };
  }

  if (option.id === 'XK0' && state.interiorColor === 'Beige') {
    return {
      available: false,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
      reason: 'Nicht in Verb. mit Polster Beige',
    };
  }

  if (option.id === 'AW7' && state.seatPackageId === 'W2E') {
    return {
      available: false,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
      reason: 'Nicht in Verb. mit OPC Line Recaro-Sportsitz (W2E)',
    };
  }

  if (option.id === 'WBP' && state.selectedOptionIds.includes('NOTRAD')) {
    return {
      available: false,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
      reason: 'Nicht in Verb. mit Notlaufrad 16"',
    };
  }

  if (option.id === 'NOTRAD') {
    const hasOpcExt = hasSportEditionPaket || state.selectedOptionIds.includes('WBP');
    const has20Wheel =
      state.wheelId === 'Q9U' ||
      seatPkg?.includedWheelInches === 20;
    if (hasOpcExt) {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nicht in Verb. mit OPC Line-Paket Exterieur',
      };
    }
    if (has20Wheel) {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nicht in Verb. mit 20"-Leichtmetallrädern (Q9U)',
      };
    }
  }

  if (option.id === 'K07') {
    const allowedEngines = [
      '16_turbo',
      '20_turbo_6g',
      '20_turbo_6g_4x4',
      '20_turbo_at',
      '20_turbo_at_4x4',
      '28_v6_6g_4x4',
      '28_v6_at_4x4',
      '20_cdti_96',
      '20_cdti_96_at',
      '20_cdti_96_ecoflex',
      '20_cdti_118',
      '20_cdti_118_4x4',
      '20_cdti_118_at',
      '20_cdti_118_at_4x4',
      '20_cdti_118_ecoflex',
    ];
    if (!allowedEngines.includes(state.engineId)) {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nur für 1.6 Turbo, 2.0 Turbo, 2.8 V6 Turbo und 2.0 CDTI (96/118 kW)',
      };
    }
    if (state.selectedOptionIds.includes('C32')) {
      return {
        available: false,
        includedAsSerie: false,
        includedInPackage: null,
        priceBrutto: 0,
        priceNetto: 0,
        reason: 'Nicht in Verb. mit Quickheat Schnellheizsystem (C32)',
      };
    }
  }

  if (option.id === 'C32' && state.selectedOptionIds.includes('K07')) {
    return {
      available: false,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
      reason: 'Nicht in Verb. mit Standheizung (K07)',
    };
  }

  if (trimPrice === 'SERIE') {
    return {
      available: true,
      includedAsSerie: true,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
    };
  }

  if (trimPrice === 'OHNE_MEHRPREIS') {
    return {
      available: true,
      includedAsSerie: false,
      includedInPackage: null,
      priceBrutto: 0,
      priceNetto: 0,
    };
  }

  return {
    available: true,
    includedAsSerie: false,
    includedInPackage: null,
    priceBrutto: trimPrice.brutto,
    priceNetto: trimPrice.netto,
  };
}

export function sanitizeConfiguration(
  next: ConfigurationState,
  onFixNotice?: (msg: string) => void
): ConfigurationState {
  const updated = { ...next, selectedOptionIds: [...next.selectedOptionIds] };
  const notes: string[] = [];

  // 1. Validate Engine for BodyStyle + Trim
  const availableEngines = getAvailableEngines(updated.bodyStyle, updated.trim);
  if (!availableEngines.some((e) => e.id === updated.engineId)) {
    const fallback = availableEngines[0];
    if (fallback) {
      updated.engineId = fallback.id;
      notes.push(`Motor auf ${fallback.name} angepasst (in ${TRIM_LINES[updated.trim].name} verfügbar).`);
    }
  }

  // 2. Validate Seat Package for Trim
  const seatPkg = SEAT_PACKAGES.find((s) => s.id === updated.seatPackageId);
  if (!seatPkg || !seatPkg.prices[updated.trim]) {
    updated.seatPackageId = 'STD';
    notes.push('Sitz-/Polsterpaket auf Serienausstattung zurückgesetzt.');
  }

  const activeSeat = SEAT_PACKAGES.find((s) => s.id === updated.seatPackageId)!;
  // Interior color constraints
  if (activeSeat.id.includes('TAFR') || activeSeat.id.includes('NAPPA')) {
    updated.interiorColor = 'Indian Summer (Cognac)';
  } else if (updated.interiorColor === 'Indian Summer (Cognac)') {
    updated.interiorColor = 'Schwarz';
  } else if (
    updated.interiorColor === 'Beige' &&
    (updated.trim === 'sport' || !activeSeat.hasBeigeOption)
  ) {
    updated.interiorColor = 'Schwarz';
  }

  // 3. Wheel sync if Premium Package specifies included wheels
  if (activeSeat.includedWheelInches === 18) {
    if (!['Q56', 'Q60', 'Q02'].includes(updated.wheelId)) {
      updated.wheelId = updated.trim === 'sport' ? 'Q02' : 'Q56';
    }
  } else if (activeSeat.includedWheelInches === 19) {
    if (!['Q9S', 'Q93'].includes(updated.wheelId)) {
      updated.wheelId = 'Q9S';
    }
  } else if (activeSeat.includedWheelInches === 20) {
    updated.wheelId = 'Q9U';
  } else {
    const wheel = WHEELS.find((w) => w.id === updated.wheelId);
    const wheelPrice = wheel?.prices[updated.trim];
    const engine = ENGINES.find((e) => e.id === updated.engineId);
    const isSt4x4 = updated.bodyStyle === 'tourer' && Boolean(engine?.is4x4);
    if (!wheel || !wheelPrice || (wheel.id === 'Q00' && isSt4x4)) {
      updated.wheelId = getDefaultWheelForTrim(updated.trim);
    }
  }

  // 4. Filter invalid options for bodyStyle / trim / conflicts
  updated.selectedOptionIds = updated.selectedOptionIds.filter((optId) => {
    const opt = CONFIG_OPTIONS.find((o) => o.id === optId);
    if (!opt) return false;
    const status = getOptionStatus(opt, updated);
    if (!status.available || status.includedAsSerie) return false;
    return true;
  });

  // 5. Filter accessories
  const engine = ENGINES.find((e) => e.id === updated.engineId);
  updated.selectedAccessoryIds = updated.selectedAccessoryIds.filter((accId) => {
    const acc = ACCESSORIES.find((a) => a.id === accId);
    if (!acc) return false;
    if (!acc.availableTrims.includes(updated.trim)) return false;
    if (acc.bodyStyles && !acc.bodyStyles.includes(updated.bodyStyle)) return false;
    if (acc.engineFilter && engine && !acc.engineFilter.includes(engine.id)) return false;
    return true;
  });

  // 6. Ensure decor valid
  if (updated.trim === 'selection') updated.decorId = 'titanium';
  else if (updated.trim === 'edition') {
    updated.decorId = updated.interiorColor === 'Beige' ? 'titanium_oliv' : 'titanium';
  } else if (updated.trim === 'sport') {
    updated.decorId = 'klavierlack';
  } else {
    if (updated.interiorColor === 'Beige') updated.decorId = 'kibo_holz';
    else if (updated.decorId !== 'kibo_holz' && updated.decorId !== 'klavierlack') {
      updated.decorId = 'kibo_holz';
    }
  }

  if (notes.length > 0 && onFixNotice) {
    onFixNotice(notes.join(' '));
  }
  return updated;
}

export function evaluateConfiguration(
  state: ConfigurationState,
  applyUpdate: (updater: (prev: ConfigurationState) => ConfigurationState) => void
) {
  const body = BODY_STYLES[state.bodyStyle];
  const trim = TRIM_LINES[state.trim];
  const engine = ENGINES.find((e) => e.id === state.engineId) || getAvailableEngines(state.bodyStyle, state.trim)[0];
  const basePrice = engine.prices[state.bodyStyle]?.[state.trim] || { brutto: 0, netto: 0 };

  const lineItems: LineItem[] = [];
  const notices: ValidationNotice[] = [];

  // Paint
  const paint = PAINT_COLORS.find((p) => p.id === state.paintId) || PAINT_COLORS[3];
  if (paint.price.brutto > 0) {
    lineItems.push({
      id: `paint_${paint.id}`,
      code: paint.code,
      label: `Lackierung ${paint.name} (${paint.type})`,
      category: 'Exterieur',
      brutto: paint.price.brutto,
      netto: paint.price.netto,
    });
  }

  // Seat Package
  const seatPkg = SEAT_PACKAGES.find((s) => s.id === state.seatPackageId) || SEAT_PACKAGES[0];
  const seatPrice = seatPkg.prices[state.trim];
  if (seatPkg.id !== 'STD' && seatPrice) {
    lineItems.push({
      id: `seat_${seatPkg.id}`,
      code: seatPkg.code,
      label: `${seatPkg.name} (${state.interiorColor})`,
      category: 'Sitze & Polster',
      brutto: seatPrice.brutto,
      netto: seatPrice.netto,
    });
  }

  // Wheels (if not already included via Premium-Paket!)
  const wheel = WHEELS.find((w) => w.id === state.wheelId);
  if (wheel) {
    const wheelTrimPrice = wheel.prices[state.trim];
    if (seatPkg.includedWheelInches) {
      // Included in Premium Package (only note if Q93/Q9S choice or 18" choice)
      lineItems.push({
        id: `wheel_${wheel.id}`,
        code: wheel.code,
        label: `${wheel.name} (${wheel.tireSpec})`,
        category: 'Fahrwerk & Räder',
        brutto: 0,
        netto: 0,
        note: 'Im Premium-Paket enthalten',
      });
    } else if (wheelTrimPrice && typeof wheelTrimPrice === 'object') {
      lineItems.push({
        id: `wheel_${wheel.id}`,
        code: wheel.code,
        label: `${wheel.name} (${wheel.tireSpec})`,
        category: 'Fahrwerk & Räder',
        brutto: wheelTrimPrice.brutto,
        netto: wheelTrimPrice.netto,
      });
    }
  }

  // Infotainment system
  const infoSys = INFOTAINMENT_SYSTEMS.find((i) => i.id === state.infotainmentId);
  if (infoSys) {
    const infoPrice = infoSys.prices[state.trim];
    if (!infoPrice.isSerie) {
      lineItems.push({
        id: `info_${infoSys.id}`,
        code: infoSys.code,
        label: infoSys.name,
        category: 'Infotainment',
        brutto: infoPrice.brutto,
        netto: infoPrice.netto,
        note: infoPrice.brutto < 0 ? 'Minderpreis gegenüber Serien-Navi' : undefined,
      });
    }
  }

  // Phone Prep
  if (state.phonePrepId) {
    const phone = PHONE_PREPS.find((p) => p.id === state.phonePrepId);
    if (phone) {
      lineItems.push({
        id: `phone_${phone.id}`,
        code: phone.code,
        label: phone.name,
        category: 'Infotainment',
        brutto: phone.price.brutto,
        netto: phone.price.netto,
      });
      if (state.trim === 'selection' && !state.selectedOptionIds.includes('PH4B')) {
        notices.push({
          id: 'phone_needs_ph4b',
          type: 'action',
          message: `Mobiltelefon-Vorbereitung (${phone.code}) erfordert bei Selection den Geschwindigkeitsregler inkl. Lederlenkrad (PH4B, +460 €).`,
          actionLabel: 'PH4B hinzufügen',
          onFix: () =>
            applyUpdate((prev) => ({
              ...prev,
              selectedOptionIds: [...new Set([...prev.selectedOptionIds, 'PH4B'])],
            })),
        });
      }
    }
  }

  // Selected Options
  const hasInnovationsPaket = state.selectedOptionIds.includes('PHLC_INNO');
  const hasSichtPaket =
    state.trim === 'innovation' ||
    hasInnovationsPaket ||
    state.selectedOptionIds.includes('TSQ');
  const hasZweiZonenKlima =
    state.trim === 'innovation' || state.selectedOptionIds.includes('CJ2');
  const hasElFensterHinten =
    state.trim === 'innovation' ||
    seatPkg.hasLeather ||
    state.selectedOptionIds.includes('AER');
  const hasSitzPaket2OrMemory =
    Boolean(seatPkg.hasAgrPassenger) ||
    state.selectedOptionIds.includes('A6D') ||
    state.selectedOptionIds.includes('AG1');

  for (const optId of state.selectedOptionIds) {
    const opt = CONFIG_OPTIONS.find((o) => o.id === optId);
    if (!opt) continue;
    const status = getOptionStatus(opt, state);
    if (!status.available) continue;
    lineItems.push({
      id: `opt_${opt.id}`,
      code: opt.code,
      label: opt.name,
      category: opt.category,
      brutto: status.priceBrutto,
      netto: status.priceNetto,
      note: status.includedInPackage || undefined,
    });
  }

  // Dependency Notices
  if (
    !hasSichtPaket &&
    (state.selectedOptionIds.includes('TT2') ||
      state.selectedOptionIds.includes('UVT') ||
      state.selectedOptionIds.includes('DWH') ||
      state.selectedOptionIds.includes('CJ2') ||
      state.selectedOptionIds.includes('AG1') ||
      seatPkg.requiresSichtPaket)
  ) {
    notices.push({
      id: 'needs_tsq',
      type: 'action',
      message: 'Eine gewählte Ausstattung (z. B. AFL+, Frontkamera, 2-Zonen-Klima, Recaro oder el. Spiegel/Memory) erfordert das Sicht-Paket (TSQ, +200 €).',
      actionLabel: 'Sicht-Paket hinzufügen',
      onFix: () =>
        applyUpdate((prev) => ({
          ...prev,
          selectedOptionIds: [...new Set([...prev.selectedOptionIds, 'TSQ'])],
        })),
    });
  }

  if (state.selectedOptionIds.includes('K07') && !hasZweiZonenKlima) {
    notices.push({
      id: 'k07_needs_cj2',
      type: 'action',
      message: 'Die Standheizung (K07) ist nur in Verbindung mit der Zwei-Zonen-Klimatisierungsautomatik (CJ2, +395 €) bestellbar.',
      actionLabel: '2-Zonen-Klima hinzufügen',
      onFix: () =>
        applyUpdate((prev) => ({
          ...prev,
          selectedOptionIds: [
            ...new Set([...prev.selectedOptionIds.filter((x) => x !== 'C68'), 'CJ2', 'TSQ']),
          ],
        })),
    });
  }

  if (state.selectedOptionIds.includes('DE8') && !hasElFensterHinten) {
    notices.push({
      id: 'de8_needs_aer',
      type: 'action',
      message: 'Sonnenschutzrollos hinten (DE8) erfordern elektrische Fensterheber vorn und hinten (AER, +375 €).',
      actionLabel: 'El. Fensterheber hinzufügen',
      onFix: () =>
        applyUpdate((prev) => ({
          ...prev,
          selectedOptionIds: [...new Set([...prev.selectedOptionIds, 'AER'])],
        })),
    });
  }

  if (
    (state.selectedOptionIds.includes('C3U') || state.selectedOptionIds.includes('CF5')) &&
    !hasSitzPaket2OrMemory
  ) {
    notices.push({
      id: 'roof_needs_a6d',
      type: 'action',
      message: 'Das elektrische Schiebe-/Panoramadach erfordert Sitz-Paket 2 (A6D, +295 €) oder elektrische Sitzeinstellung (AG1).',
      actionLabel: 'Sitz-Paket 2 hinzufügen',
      onFix: () =>
        applyUpdate((prev) => ({
          ...prev,
          selectedOptionIds: [...new Set([...prev.selectedOptionIds, 'A6D'])],
        })),
    });
  }

  // Warranty
  if (state.warrantyId) {
    const w = WARRANTIES.find((x) => x.id === state.warrantyId);
    if (w) {
      lineItems.push({
        id: `war_${w.id}`,
        code: w.code,
        label: w.name,
        category: 'Anschlussgarantie',
        brutto: w.price.brutto,
        netto: w.price.netto,
      });
    }
  }

  // Accessories
  const accessoryItems: LineItem[] = [];
  for (const accId of state.selectedAccessoryIds) {
    const acc = ACCESSORIES.find((a) => a.id === accId);
    if (!acc) continue;
    accessoryItems.push({
      id: `acc_${acc.id}`,
      code: acc.orderKey,
      label: acc.name,
      category: `Zubehör · ${acc.category}`,
      brutto: acc.price.brutto,
      netto: acc.price.netto,
    });
  }

  const optionsBrutto = lineItems.reduce((sum, item) => sum + item.brutto, 0);
  const optionsNetto = lineItems.reduce((sum, item) => sum + item.netto, 0);
  const accessoriesBrutto = accessoryItems.reduce((sum, item) => sum + item.brutto, 0);
  const accessoriesNetto = accessoryItems.reduce((sum, item) => sum + item.netto, 0);

  const totalBrutto = Math.round((basePrice.brutto + optionsBrutto + accessoriesBrutto) * 100) / 100;
  const totalNetto = Math.round((basePrice.netto + optionsNetto + accessoriesNetto) * 100) / 100;

  // Compute dynamic trunk volume (Page 36)
  const hasNotrad = state.selectedOptionIds.includes('NOTRAD');
  const hasInfinity = state.selectedOptionIds.includes('UQA');
  let trunkReduction = 0;
  if (hasNotrad && hasInfinity) {
    trunkReduction = state.bodyStyle === 'limo5' ? 106 : 30;
  } else if (hasNotrad) {
    trunkReduction = 22;
  } else if (hasInfinity) {
    trunkReduction = state.bodyStyle === 'limo5' ? 84 : 8;
  }
  const effectiveTrunkL = body.trunkVolumeStandardL - trunkReduction;

  const perf =
    state.bodyStyle === 'tourer' ? engine.performance.tourer : engine.performance.limousine;

  return {
    body,
    trim,
    engine,
    paint,
    seatPkg,
    wheel,
    basePrice,
    lineItems,
    accessoryItems,
    optionsBrutto,
    optionsNetto,
    accessoriesBrutto,
    accessoriesNetto,
    totalBrutto,
    totalNetto,
    vatAmount: Math.round((totalBrutto - totalNetto) * 100) / 100,
    notices,
    effectiveTrunkL,
    trunkReduction,
    perf,
  };
}

export function getDisplayPrice(brutto: number, netto: number, mode: PriceMode): number {
  return mode === 'brutto' ? brutto : netto;
}
