import React, { useMemo, useState } from 'react';
import {
  ACCESSORIES,
  CONFIG_OPTIONS,
  INFOTAINMENT_SYSTEMS,
  PHONE_PREPS,
  WARRANTIES,
} from '../data/insignia2010';
import { ConfigurationState, OptionCategoryId, PriceMode } from '../types/configurator';
import { formatEuro, getOptionStatus } from '../utils/configEngine';
import { Check, Search } from 'lucide-react';

interface StepSonderausstattungProps {
  state: ConfigurationState;
  priceMode: PriceMode;
  onToggleOption: (optionId: string) => void;
  onSelectInfotainment: (id: 'UZZ' | 'UXW' | 'UXX') => void;
  onSelectPhonePrep: (id: string | null) => void;
  onSelectWarranty: (id: string | null) => void;
  onToggleAccessory: (accId: string) => void;
  onNext: () => void;
}

type CategoryTab = 'alle' | OptionCategoryId | 'zubehoer';

const CATEGORY_TABS: { id: CategoryTab; label: string }[] = [
  { id: 'alle', label: 'Alle Extras' },
  { id: 'pakete', label: 'Pakete & Sitze' },
  { id: 'innovationen', label: 'Innovationen' },
  { id: 'sicherheit', label: 'Sicherheit & Fahrwerk' },
  { id: 'infotainment', label: 'Infotainment & Telefon' },
  { id: 'komfort', label: 'Komfort & Dach' },
  { id: 'garantie', label: 'Garantie' },
  { id: 'zubehoer', label: 'Original Zubehör' },
];

export const StepSonderausstattung: React.FC<StepSonderausstattungProps> = ({
  state,
  priceMode,
  onToggleOption,
  onSelectInfotainment,
  onSelectPhonePrep,
  onSelectWarranty,
  onToggleAccessory,
  onNext,
}) => {
  const [activeTab, setActiveTab] = useState<CategoryTab>('alle');
  const [query, setQuery] = useState('');
  const [hideUnavailable, setHideUnavailable] = useState(false);

  const normalizedQuery = query.trim().toLowerCase();

  const filteredOptions = useMemo(() => {
    return CONFIG_OPTIONS.filter((opt) => {
      if (activeTab !== 'alle' && opt.category !== activeTab) return false;
      if (normalizedQuery) {
        const hay = `${opt.name} ${opt.code} ${opt.description}`.toLowerCase();
        if (!hay.includes(normalizedQuery)) return false;
      }
      if (hideUnavailable) {
        const st = getOptionStatus(opt, state);
        if (!st.available) return false;
      }
      return true;
    });
  }, [activeTab, normalizedQuery, hideUnavailable, state]);

  const filteredAccessories = useMemo(() => {
    if (activeTab !== 'alle' && activeTab !== 'zubehoer') return [];
    return ACCESSORIES.filter((acc) => {
      if (!acc.availableTrims.includes(state.trim)) return false;
      if (acc.bodyStyles && !acc.bodyStyles.includes(state.bodyStyle)) return false;
      if (acc.engineFilter && !acc.engineFilter.includes(state.engineId)) return false;
      if (normalizedQuery) {
        const hay = `${acc.name} ${acc.orderKey} ${acc.category}`.toLowerCase();
        if (!hay.includes(normalizedQuery)) return false;
      }
      return true;
    });
  }, [activeTab, normalizedQuery, state]);

  const showInfotainmentBlock = activeTab === 'alle' || activeTab === 'infotainment';
  const showWarrantyBlock = activeTab === 'alle' || activeTab === 'garantie';

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-bold text-[#141517]">
            07. Pakete, Sonderausstattung & Zubehör
          </h2>
          <p className="mt-1 text-sm text-[#5C6068]">
            Sämtliche Werksoptionen (Seiten 14–32) und Original Opel Zubehör (Seiten 33–35) mit
            Bestellschlüsseln.
          </p>
        </div>

        <label className="flex items-center gap-2 text-xs text-[#5C6068] cursor-pointer select-none">
          <input
            type="checkbox"
            checked={hideUnavailable}
            onChange={(e) => setHideUnavailable(e.target.checked)}
            className="h-4 w-4 rounded border-[#D1D5DB] accent-[#141517]"
          />
          Nur verfügbare anzeigen
        </label>
      </div>

      {/* Search & Category Controls */}
      <div className="flex flex-col gap-3">
        <div className="relative">
          <Search
            className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#5C6068]"
            aria-hidden="true"
          />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Suche nach Ausstattung oder Bestellcode (z. B. AFL+, FlexRide, TT2, URC, K07, Thule)..."
            className="w-full rounded-xl border border-[#DCDEE2] bg-white py-2.5 pl-10 pr-4 text-sm text-[#141517] placeholder:text-[#8A8F98] focus:border-[#141517] focus:outline-none"
          />
        </div>

        <div className="flex flex-wrap items-center gap-1 rounded-lg bg-[#EAEBE8] p-1">
          {CATEGORY_TABS.map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                activeTab === tab.id
                  ? 'bg-white text-[#141517] shadow-xs'
                  : 'text-[#5C6068] hover:text-[#141517]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Infotainment Radio & Phone Prep Exclusive Block */}
      {showInfotainmentBlock && (
        <div className="space-y-4">
          <div className="rounded-xl border border-[#E4E5E7] bg-white p-4">
            <h3 className="font-display text-sm font-bold text-[#141517] mb-1">
              Audio- & Navigationssystem (Pflichtauswahl)
            </h3>
            <p className="text-xs text-[#5C6068] mb-3">
              Bei Edition, Sport & INNOVATION ist das DVD 800 Europa Navi serienmäßig; CD 500 bzw.
              CD 400 reduzieren den Fahrzeugpreis entsprechend der Preisliste (Seite 28).
            </p>
            <div className="grid grid-cols-1 gap-2.5">
              {INFOTAINMENT_SYSTEMS.map((sys) => {
                const isSelected = state.infotainmentId === sys.id;
                const priceInfo = sys.prices[state.trim];
                const val = priceMode === 'brutto' ? priceInfo.brutto : priceInfo.netto;
                return (
                  <button
                    key={sys.id}
                    type="button"
                    onClick={() => onSelectInfotainment(sys.id)}
                    className={`rounded-xl border p-3.5 text-left transition-all ${
                      isSelected
                        ? 'border-[#141517] bg-[#FAFAFA] ring-1 ring-[#141517]'
                        : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                    }`}
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono-tabular text-xs font-semibold text-[#5C6068]">
                          {sys.code}
                        </span>
                        <span className="font-display text-sm font-bold text-[#141517]">
                          {sys.name}
                        </span>
                        {isSelected && <Check className="h-4 w-4 text-[#D99B00]" />}
                      </div>
                      <span
                        className={`font-mono-tabular text-sm font-semibold ${
                          val < 0 ? 'text-[#15803D]' : 'text-[#141517]'
                        }`}
                      >
                        {priceInfo.isSerie
                          ? 'Serie'
                          : val > 0
                          ? `+${formatEuro(val)}`
                          : formatEuro(val)}
                      </span>
                    </div>
                    <div className="mt-1 text-xs text-[#5C6068]">{sys.subtitle}</div>
                    <ul className="mt-2 space-y-0.5 text-[11px] text-[#4B4F56]">
                      {sys.details.map((d) => (
                        <li key={d}>· {d}</li>
                      ))}
                    </ul>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-xl border border-[#E4E5E7] bg-white p-4">
            <div className="flex items-baseline justify-between gap-2 mb-3">
              <div>
                <h3 className="font-display text-sm font-bold text-[#141517]">
                  Mobiltelefon-Vorbereitung (Bluetooth™ / SAP)
                </h3>
                <p className="text-xs text-[#5C6068]">
                  Optionales Freisprech- oder integriertes SAP-Telefonmodul (Seite 29–30).
                </p>
              </div>
              {state.phonePrepId && (
                <button
                  type="button"
                  onClick={() => onSelectPhonePrep(null)}
                  className="text-xs font-medium text-[#5C6068] underline hover:text-[#141517]"
                >
                  Abwählen
                </button>
              )}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {PHONE_PREPS.map((phone) => {
                const isSelected = state.phonePrepId === phone.id;
                const price = priceMode === 'brutto' ? phone.price.brutto : phone.price.netto;
                return (
                  <button
                    key={phone.id}
                    type="button"
                    onClick={() => onSelectPhonePrep(isSelected ? null : phone.id)}
                    className={`rounded-xl border p-3 text-left transition-all ${
                      isSelected
                        ? 'border-[#141517] bg-[#FAFAFA] ring-1 ring-[#141517]'
                        : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                    }`}
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="font-mono-tabular text-xs font-semibold text-[#5C6068]">
                        {phone.code}
                      </span>
                      <span className="font-mono-tabular text-xs font-semibold text-[#141517]">
                        +{formatEuro(price)}
                      </span>
                    </div>
                    <div className="mt-1 flex items-center justify-between gap-2">
                      <span className="font-display text-xs font-bold text-[#141517]">
                        {phone.name}
                      </span>
                      {isSelected && <Check className="h-3.5 w-3.5 text-[#D99B00] shrink-0" />}
                    </div>
                    <p className="mt-1 text-[11px] text-[#5C6068]">{phone.description}</p>
                    {state.trim === 'selection' && (
                      <p className="mt-1 text-[11px] text-[#B45309]">{phone.note}</p>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Factory Options List */}
      {activeTab !== 'zubehoer' && activeTab !== 'garantie' && (
        <div className="grid grid-cols-1 gap-2.5">
          {filteredOptions.map((opt) => {
            const status = getOptionStatus(opt, state);
            const isSelected = state.selectedOptionIds.includes(opt.id);
            const isIncluded = status.includedAsSerie || Boolean(status.includedInPackage);
            const displayPrice =
              priceMode === 'brutto' ? status.priceBrutto : status.priceNetto;

            return (
              <div
                key={opt.id}
                className={`rounded-xl border p-4 transition-all ${
                  !status.available
                    ? 'border-[#E4E5E7] bg-[#FAFAFA] opacity-60'
                    : isSelected || isIncluded
                    ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                    : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6068]">
                      <span className="font-mono-tabular font-semibold text-[#141517]">
                        {opt.code}
                      </span>
                      {opt.paketBestandteil && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>Bestandteil von: {opt.paketBestandteil}</span>
                        </>
                      )}
                      {status.includedAsSerie && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-[#15803D]">Serienausstattung</span>
                        </>
                      )}
                      {status.includedInPackage && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-[#15803D]">
                            {status.includedInPackage}
                          </span>
                        </>
                      )}
                    </div>

                    <h3 className="mt-1 font-display text-sm font-bold text-[#141517]">
                      {opt.name}
                    </h3>
                    <p className="mt-1 text-xs text-[#4B4F56]">{opt.description}</p>

                    {opt.details && (
                      <ul className="mt-2 space-y-0.5 text-[11px] text-[#5C6068]">
                        {opt.details.map((d) => (
                          <li key={d}>· {d}</li>
                        ))}
                      </ul>
                    )}

                    {status.reason && (
                      <p className="mt-2 text-xs font-medium text-[#B45309]">{status.reason}</p>
                    )}
                    {opt.footnote && (
                      <p className="mt-1 text-[11px] text-[#5C6068]">{opt.footnote}</p>
                    )}
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                    <div className="font-mono-tabular text-sm font-semibold text-[#141517]">
                      {!status.available
                        ? '—'
                        : isIncluded
                        ? 'Inklusive'
                        : displayPrice === 0
                        ? 'ohne Mehrpreis'
                        : `+${formatEuro(displayPrice)}`}
                    </div>

                    {status.available && !isIncluded && (
                      <button
                        type="button"
                        onClick={() => onToggleOption(opt.id)}
                        className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                          isSelected
                            ? 'bg-[#141517] text-white'
                            : 'border border-[#141517] bg-white text-[#141517] hover:bg-[#141517] hover:text-white'
                        }`}
                      >
                        {isSelected ? 'Ausgewählt' : 'Hinzufügen'}
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Warranty Block */}
      {showWarrantyBlock && (
        <div className="rounded-xl border border-[#E4E5E7] bg-white p-4">
          <div className="flex items-baseline justify-between gap-2 mb-3">
            <div>
              <h3 className="font-display text-sm font-bold text-[#141517]">
                Opel Anschlussgarantie (CG Car-Garantie Versicherungs-AG, Seiten 14 & 35)
              </h3>
              <p className="text-xs text-[#5C6068]">
                2 Jahre Herstellergarantie ab Werk sind serienmäßig enthalten.
              </p>
            </div>
            {state.warrantyId && (
              <button
                type="button"
                onClick={() => onSelectWarranty(null)}
                className="text-xs font-medium text-[#5C6068] underline hover:text-[#141517]"
              >
                Abwählen
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {WARRANTIES.map((w) => {
              const isSelected = state.warrantyId === w.id;
              const price = priceMode === 'brutto' ? w.price.brutto : w.price.netto;
              return (
                <button
                  key={w.id}
                  type="button"
                  onClick={() => onSelectWarranty(isSelected ? null : w.id)}
                  className={`rounded-xl border p-3.5 text-left transition-all ${
                    isSelected
                      ? 'border-[#141517] bg-[#FAFAFA] ring-1 ring-[#141517]'
                      : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                  }`}
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-mono-tabular text-xs font-semibold text-[#5C6068]">
                      {w.code}
                    </span>
                    <span className="font-mono-tabular text-xs font-semibold text-[#141517]">
                      +{formatEuro(price)}
                    </span>
                  </div>
                  <div className="mt-1 font-display text-xs font-bold text-[#141517]">
                    {w.name}
                  </div>
                  <p className="mt-1 text-[11px] text-[#5C6068]">{w.description}</p>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Original Opel Accessories (Pages 33–35) */}
      {filteredAccessories.length > 0 && (
        <div className="rounded-xl border border-[#E4E5E7] bg-white p-4">
          <h3 className="font-display text-base font-bold text-[#141517] mb-1">
            Original Opel Zubehör (Seiten 33–35)
          </h3>
          <p className="text-xs text-[#5C6068] mb-4">
            Thule Trägersysteme, Kindersicherheit, Fußmatten, Felgen & Winterkompletträder mit
            originalem Bestellschlüssel.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {filteredAccessories.map((acc) => {
              const isSelected = state.selectedAccessoryIds.includes(acc.id);
              const price = priceMode === 'brutto' ? acc.price.brutto : acc.price.netto;
              return (
                <button
                  key={acc.id}
                  type="button"
                  onClick={() => onToggleAccessory(acc.id)}
                  className={`flex items-start justify-between gap-3 rounded-xl border p-3 text-left transition-all ${
                    isSelected
                      ? 'border-[#141517] bg-[#FAFAFA] ring-1 ring-[#141517]'
                      : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="text-[11px] font-mono-tabular text-[#5C6068]">
                      Best.-Nr. {acc.orderKey} · {acc.category}
                    </div>
                    <div className="mt-0.5 text-xs font-semibold text-[#141517]">{acc.name}</div>
                    {acc.description && (
                      <div className="mt-0.5 text-[11px] text-[#5C6068]">{acc.description}</div>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="font-mono-tabular text-xs font-semibold text-[#141517]">
                      +{formatEuro(price)}
                    </span>
                    {isSelected && <Check className="h-3.5 w-3.5 text-[#D99B00]" />}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      <div className="flex justify-end pt-2">
        <button
          type="button"
          onClick={onNext}
          className="rounded-lg bg-[#141517] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#2A2D32]"
        >
          Zur Zusammenfassung („Mein Insignia“)
        </button>
      </div>
    </div>
  );
};
