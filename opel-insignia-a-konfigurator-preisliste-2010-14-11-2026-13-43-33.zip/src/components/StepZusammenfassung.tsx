import React, { useState } from 'react';
import { GENERAL_STANDARD_EQUIPMENT } from '../data/insignia2010';
import {
  BodyStyleSpec,
  ConfigurationState,
  EngineSpec,
  LineItem,
  PaintColor,
  SavedBuild,
  SeatPackageOption,
  TrimLineInfo,
  WheelOption,
} from '../types/configurator';
import { formatEuro } from '../utils/configEngine';
import { Bookmark, Check, Copy, Printer, RotateCcw, Trash2 } from 'lucide-react';

interface StepZusammenfassungProps {
  state: ConfigurationState;
  body: BodyStyleSpec;
  trim: TrimLineInfo;
  engine: EngineSpec;
  paint: PaintColor;
  seatPkg: SeatPackageOption;
  wheel: WheelOption | undefined;
  basePrice: { brutto: number; netto: number };
  lineItems: LineItem[];
  accessoryItems: LineItem[];
  totalBrutto: number;
  totalNetto: number;
  vatAmount: number;
  effectiveTrunkL: number;
  trunkReduction: number;
  perf: {
    topSpeedKmh: number;
    topSpeedLimited?: boolean;
    accel0100: number;
    consumptionUrban: number;
    consumptionExtra: number;
    consumptionCombined: number;
    co2Urban: number;
    co2Extra: number;
    co2Combined: number;
  };
  savedBuilds: SavedBuild[];
  onSaveBuild: (name: string) => void;
  onLoadBuild: (build: SavedBuild) => void;
  onDeleteBuild: (id: string) => void;
  onReset: () => void;
}

export const StepZusammenfassung: React.FC<StepZusammenfassungProps> = ({
  state,
  body,
  trim,
  engine,
  paint,
  seatPkg,
  wheel,
  basePrice,
  lineItems,
  accessoryItems,
  totalBrutto,
  totalNetto,
  vatAmount,
  effectiveTrunkL,
  trunkReduction,
  perf,
  savedBuilds,
  onSaveBuild,
  onLoadBuild,
  onDeleteBuild,
  onReset,
}) => {
  const [copied, setCopied] = useState(false);
  const [buildName, setBuildName] = useState('');
  const [compareIds, setCompareIds] = useState<[string | null, string | null]>([null, null]);

  // GMAC SmartBuy / SmartLease Calculator State
  const [downPaymentPct, setDownPaymentPct] = useState(20);
  const [months, setMonths] = useState(48);
  const [apr, setApr] = useState(4.9);
  const [balloonPct, setBalloonPct] = useState(35);

  const downPayment = Math.round((totalBrutto * downPaymentPct) / 100);
  const balloon = Math.round((totalBrutto * balloonPct) / 100);
  const principal = Math.max(0, totalBrutto - downPayment);
  const monthlyRate = (() => {
    const r = apr / 100 / 12;
    if (r === 0) return (principal - balloon) / months;
    const pvBalloon = balloon / Math.pow(1 + r, months);
    const financed = Math.max(0, principal - pvBalloon);
    return (financed * r) / (1 - Math.pow(1 + r, -months));
  })();

  const handleCopySummary = async () => {
    const lines = [
      `MEIN OPEL INSIGNIA (Preisliste 21. Juni 2010)`,
      `================================================`,
      `Modell: ${body.name} · ${trim.name}`,
      `Motor: ${engine.name} (${engine.kw} kW / ${engine.ps} PS) · ${engine.transmission}`,
      `Grundpreis: ${formatEuro(basePrice.brutto)} (Netto: ${formatEuro(basePrice.netto)})`,
      `Lackierung: ${paint.name} (${paint.code})`,
      `Sitze/Interieur: ${seatPkg.name} · ${state.interiorColor}`,
      `Räder: ${wheel ? `${wheel.name} (${wheel.tireSpec})` : trim.wheelsLabel}`,
      ``,
      `SONDERAUSSTATTUNG:`,
      ...(lineItems.length > 0
        ? lineItems.map(
            (item) =>
              `- [${item.code}] ${item.label}: ${
                item.brutto === 0 ? 'Inklusive' : formatEuro(item.brutto)
              }`
          )
        : ['- Keine kostenpflichtige Sonderausstattung gewählt']),
      ...(accessoryItems.length > 0
        ? [
            ``,
            `ORIGINAL OPEL ZUBEHÖR:`,
            ...accessoryItems.map(
              (acc) => `- [${acc.code}] ${acc.label}: ${formatEuro(acc.brutto)}`
            ),
          ]
        : []),
      ``,
      `GESAMTPREIS (ohne MwSt.): ${formatEuro(totalNetto)}`,
      `GESAMTPREIS (inkl. 19% MwSt.): ${formatEuro(totalBrutto)}`,
    ];

    try {
      await navigator.clipboard.writeText(lines.join('\n'));
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      setCopied(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const defaultTitle = `${body.shortName} ${trim.name} ${engine.ps} PS`;
    onSaveBuild(buildName.trim() || defaultTitle);
    setBuildName('');
  };

  const toggleCompare = (id: string) => {
    setCompareIds(([a, b]) => {
      if (a === id) return [b, null];
      if (b === id) return [a, null];
      if (!a) return [id, b];
      if (!b) return [a, id];
      return [b, id];
    });
  };

  const buildA = savedBuilds.find((b) => b.id === compareIds[0]);
  const buildB = savedBuilds.find((b) => b.id === compareIds[1]);

  return (
    <div className="flex flex-col gap-6">
      {/* Action Header */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-[#141517]">Mein Insignia</h2>
          <p className="mt-1 text-sm text-[#5C6068]">
            Unverbindliche Preisempfehlung ab Werk gemäß Preisliste Stand 21. Juni 2010.
          </p>
        </div>

        <div className="no-print flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleCopySummary}
            className="flex items-center gap-1.5 rounded-lg border border-[#DCDEE2] bg-white px-3.5 py-2 text-xs font-semibold text-[#141517] hover:bg-[#F2F3F0] transition-colors whitespace-nowrap shrink-0"
          >
            {copied ? <Check className="h-3.5 w-3.5 text-[#15803D]" /> : <Copy className="h-3.5 w-3.5" />}
            {copied ? 'Kopiert' : 'Text kopieren'}
          </button>
          <button
            type="button"
            onClick={() => window.print()}
            className="flex items-center gap-1.5 rounded-lg bg-[#141517] px-3.5 py-2 text-xs font-semibold text-white hover:bg-[#2A2D32] transition-colors whitespace-nowrap shrink-0"
          >
            <Printer className="h-3.5 w-3.5" />
            Drucken / PDF
          </button>
          <button
            type="button"
            onClick={onReset}
            className="flex items-center gap-1.5 rounded-lg border border-[#DCDEE2] bg-white px-3.5 py-2 text-xs font-medium text-[#5C6068] hover:text-[#141517] transition-colors whitespace-nowrap shrink-0"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            Neu starten
          </button>
        </div>
      </div>

      {/* Authentic Page 43 "Mein Insignia" Price Breakdown Table */}
      <div className="rounded-xl border border-[#E4E5E7] bg-white overflow-hidden print:overflow-visible">
        <div className="border-b border-[#E4E5E7] bg-[#141517] px-5 py-3 text-white flex items-center justify-between">
          <span className="font-display text-sm font-bold">Modell / Motor & Sonderausstattung</span>
          <span className="font-mono-tabular text-xs text-white/80">
            Alle Preise in EUR (Brutto / Netto)
          </span>
        </div>

        <div className="divide-y divide-[#F0F1F3] text-sm">
          {/* Base Vehicle */}
          <div className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-[#FAFAFA]">
            <div>
              <div className="text-xs font-medium text-[#5C6068]">
                Basismodell · {body.name} · Ausstattungslinie {trim.name}
              </div>
              <div className="font-display font-bold text-[#141517]">
                {engine.name} ({engine.kw} kW / {engine.ps} PS) · {engine.transmission}
              </div>
            </div>
            <div className="text-right font-mono-tabular shrink-0">
              <div className="font-semibold text-[#141517]">{formatEuro(basePrice.brutto)}</div>
              <div className="text-xs text-[#5C6068]">Netto: {formatEuro(basePrice.netto)}</div>
            </div>
          </div>

          {/* Paint if uni */}
          {paint.price.brutto === 0 && (
            <div className="px-4 py-3 flex items-center justify-between gap-3 text-xs">
              <div>
                <span className="font-mono-tabular font-semibold text-[#5C6068] mr-2">
                  {paint.code}
                </span>
                <span className="text-[#141517]">Lackierung {paint.name} ({paint.type})</span>
              </div>
              <span className="font-mono-tabular text-[#5C6068]">Serie</span>
            </div>
          )}

          {/* Selected Options */}
          {lineItems.map((item) => (
            <div key={item.id} className="px-4 py-3 flex items-center justify-between gap-3 text-xs">
              <div className="min-w-0">
                <span className="font-mono-tabular font-semibold text-[#5C6068] mr-2">
                  {item.code}
                </span>
                <span className="font-medium text-[#141517]">{item.label}</span>
                {item.note && (
                  <span className="ml-2 text-[11px] text-[#5C6068]">({item.note})</span>
                )}
              </div>
              <div className="text-right font-mono-tabular shrink-0">
                <span className={item.brutto < 0 ? 'font-semibold text-[#15803D]' : 'font-semibold text-[#141517]'}>
                  {item.brutto === 0 ? 'Inklusive' : formatEuro(item.brutto)}
                </span>
                {item.brutto !== 0 && (
                  <span className="ml-2 text-[11px] text-[#5C6068]">
                    ({formatEuro(item.netto)})
                  </span>
                )}
              </div>
            </div>
          ))}

          {/* Accessories */}
          {accessoryItems.length > 0 && (
            <>
              <div className="bg-[#F7F7F5] px-4 py-2 text-xs font-semibold text-[#5C6068]">
                Original Opel Zubehör
              </div>
              {accessoryItems.map((acc) => (
                <div
                  key={acc.id}
                  className="px-4 py-3 flex items-center justify-between gap-3 text-xs"
                >
                  <div>
                    <span className="font-mono-tabular font-semibold text-[#5C6068] mr-2">
                      {acc.code}
                    </span>
                    <span className="font-medium text-[#141517]">{acc.label}</span>
                  </div>
                  <div className="text-right font-mono-tabular shrink-0">
                    <span className="font-semibold text-[#141517]">{formatEuro(acc.brutto)}</span>
                    <span className="ml-2 text-[11px] text-[#5C6068]">
                      ({formatEuro(acc.netto)})
                    </span>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        {/* Totals Footer */}
        <div className="border-t-2 border-[#141517] bg-[#FAFAFA] p-4 space-y-1.5">
          <div className="flex justify-between text-xs text-[#5C6068]">
            <span>Gesamtpreis ohne MwSt. (Netto)</span>
            <span className="font-mono-tabular font-medium text-[#141517]">
              {formatEuro(totalNetto)}
            </span>
          </div>
          <div className="flex justify-between text-xs text-[#5C6068]">
            <span>zuzüglich 19 % gesetzliche MwSt.</span>
            <span className="font-mono-tabular font-medium text-[#141517]">
              {formatEuro(vatAmount)}
            </span>
          </div>
          <div className="pt-2 border-t border-[#E4E5E7] flex items-baseline justify-between">
            <span className="font-display text-base font-bold text-[#141517]">
              Gesamtpreis (inkl. 19 % MwSt.)
            </span>
            <span className="font-mono-tabular text-2xl font-bold text-[#141517]">
              {formatEuro(totalBrutto)}
            </span>
          </div>
        </div>
      </div>

      {/* Technical Data & Luggage Details */}
      <div className="no-print grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="rounded-xl border border-[#E4E5E7] bg-white p-4 text-xs">
          <h3 className="font-display text-sm font-bold text-[#141517] mb-3">
            Fahrleistungen, Verbrauch & CO₂ (Seiten 39–42)
          </h3>
          <dl className="space-y-2">
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Hubraum / Zylinder</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {engine.displacementCc} cm³ · {engine.cylinders}-Zylinder
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Max. Leistung</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {engine.kw} kW ({engine.ps} PS) bei {engine.rpmPower} min⁻¹
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Max. Drehmoment</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {engine.torqueNm} Nm ({engine.torqueRpm} min⁻¹)
                {engine.overboostNm ? ` · Overboost ${engine.overboostNm} Nm` : ''}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Höchstgeschwindigkeit</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {perf.topSpeedKmh} km/h{perf.topSpeedLimited ? ' (abgeregelt)' : ''}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Beschleunigung 0–100 km/h</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {perf.accel0100.toFixed(1).replace('.', ',')} s
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Verbrauch (innerorts / außerorts / komb.)</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {perf.consumptionUrban.toFixed(1).replace('.', ',')} /{' '}
                {perf.consumptionExtra.toFixed(1).replace('.', ',')} /{' '}
                {perf.consumptionCombined.toFixed(1).replace('.', ',')} l/100km
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">CO₂-Emission (kombiniert)</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {perf.co2Combined} g/km ({engine.emissionStandard})
              </dd>
            </div>
          </dl>
        </div>

        <div className="rounded-xl border border-[#E4E5E7] bg-white p-4 text-xs">
          <h3 className="font-display text-sm font-bold text-[#141517] mb-3">
            Maße, Gepäckraum & Anhängelasten (Seiten 36–37, 41–42)
          </h3>
          <dl className="space-y-2">
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Länge × Breite (ohne/mit Spiegel) × Höhe</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {body.lengthMm} × {body.widthWithoutMirrorsMm}/{body.widthWithMirrorsMm} × {body.heightMm} mm
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Gepäckraumvolumen (aktuell konfiguriert)</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {effectiveTrunkL} l{' '}
                {trunkReduction > 0 ? `(−${trunkReduction} l Abzug)` : '(Standard)'}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Bei umgeklappter Rücksitzlehne</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {body.trunkVolumeFoldedWindowL} l
                {body.trunkVolumeFoldedRoofL ? ` (bis Dach: ${body.trunkVolumeFoldedRoofL} l)` : ''}
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Leergewicht / zul. Gesamtgewicht / Dachlast</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {body.curbWeightKg} / {body.grossWeightKg} / {body.roofLoadKg} kg
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Anhängelast ungebremst / 12 % Steigung</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {engine.towing.limoUnbraked} kg /{' '}
                {state.bodyStyle === 'tourer'
                  ? engine.towing.tourer12Percent
                  : engine.towing.limo12Percent}{' '}
                kg
              </dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-[#5C6068]">Tankinhalt</dt>
              <dd className="font-mono-tabular font-medium text-[#141517]">
                {engine.tankLiters} Liter ({engine.fuelLabel})
              </dd>
            </div>
          </dl>
        </div>
      </div>

      {/* GMAC SmartBuy Finanzierungsrechner (Seite 44) */}
      <div className="no-print rounded-xl border border-[#E4E5E7] bg-white p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-2 mb-4">
          <div>
            <h3 className="font-display text-base font-bold text-[#141517]">
              GMAC Bank SmartBuy Finanzierungsrechner (Beispielrechnung)
            </h3>
            <p className="text-xs text-[#5C6068]">
              Unverbindliche Raten-Orientierung auf Basis des gewählten Gesamtpreises (Seite 44).
            </p>
          </div>
          <div className="text-right">
            <div className="text-[11px] text-[#5C6068]">Geschätzte Monatsrate</div>
            <div className="font-mono-tabular text-xl font-bold text-[#141517]">
              {formatEuro(Math.round(monthlyRate))} / Monat
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-[#5C6068]">Anzahlung ({downPaymentPct}%)</span>
              <span className="font-mono-tabular font-semibold">{formatEuro(downPayment)}</span>
            </div>
            <input
              type="range"
              min={0}
              max={50}
              step={5}
              value={downPaymentPct}
              onChange={(e) => setDownPaymentPct(Number(e.target.value))}
              className="w-full accent-[#141517]"
            />
          </div>
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-[#5C6068]">Laufzeit</span>
              <span className="font-mono-tabular font-semibold">{months} Monate</span>
            </div>
            <input
              type="range"
              min={12}
              max={60}
              step={12}
              value={months}
              onChange={(e) => setMonths(Number(e.target.value))}
              className="w-full accent-[#141517]"
            />
          </div>
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-[#5C6068]">Schlussrate ({balloonPct}%)</span>
              <span className="font-mono-tabular font-semibold">{formatEuro(balloon)}</span>
            </div>
            <input
              type="range"
              min={0}
              max={45}
              step={5}
              value={balloonPct}
              onChange={(e) => setBalloonPct(Number(e.target.value))}
              className="w-full accent-[#141517]"
            />
          </div>
          <div>
            <div className="flex justify-between mb-1">
              <span className="text-[#5C6068]">Eff. Jahreszins</span>
              <span className="font-mono-tabular font-semibold">{apr.toFixed(1).replace('.', ',')} %</span>
            </div>
            <input
              type="range"
              min={0}
              max={7.9}
              step={0.5}
              value={apr}
              onChange={(e) => setApr(Number(e.target.value))}
              className="w-full accent-[#141517]"
            />
          </div>
        </div>
      </div>

      {/* Save & Compare Garage */}
      <div className="no-print rounded-xl border border-[#E4E5E7] bg-white p-5">
        <h3 className="font-display text-base font-bold text-[#141517] mb-1">
          Konfigurationen speichern & vergleichen
        </h3>
        <p className="text-xs text-[#5C6068] mb-4">
          Speichern Sie mehrere Varianten (z. B. Edition Diesel vs. Sport Turbo), um sie direkt
          gegenüberzustellen.
        </p>

        <form onSubmit={handleSave} className="flex flex-wrap gap-2 mb-4">
          <input
            type="text"
            value={buildName}
            onChange={(e) => setBuildName(e.target.value)}
            placeholder={`Name (z. B. ${body.shortName} ${trim.name} ${engine.ps} PS)`}
            className="flex-1 min-w-[220px] rounded-lg border border-[#DCDEE2] px-3 py-2 text-xs text-[#141517] focus:border-[#141517] focus:outline-none"
          />
          <button
            type="submit"
            className="flex items-center gap-1.5 rounded-lg bg-[#141517] px-4 py-2 text-xs font-semibold text-white hover:bg-[#2A2D32] transition-colors whitespace-nowrap shrink-0"
          >
            <Bookmark className="h-3.5 w-3.5" />
            Konfiguration merken
          </button>
        </form>

        {savedBuilds.length > 0 && (
          <div className="space-y-2">
            {savedBuilds.map((b) => {
              const isSelectedCompare = compareIds.includes(b.id);
              return (
                <div
                  key={b.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[#E4E5E7] p-3 text-xs"
                >
                  <div className="min-w-0">
                    <div className="font-semibold text-[#141517]">{b.name}</div>
                    <div className="text-[#5C6068]">
                      {b.summaryTitle} ·{' '}
                      <span className="font-mono-tabular font-medium text-[#141517]">
                        {formatEuro(b.totalBrutto)}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => toggleCompare(b.id)}
                      className={`rounded-md border px-2.5 py-1 text-xs font-medium transition-colors ${
                        isSelectedCompare
                          ? 'border-[#141517] bg-[#141517] text-white'
                          : 'border-[#DCDEE2] bg-white text-[#141517] hover:bg-[#F7F7F5]'
                      }`}
                    >
                      {isSelectedCompare ? 'Im Vergleich' : 'Vergleichen'}
                    </button>
                    <button
                      type="button"
                      onClick={() => onLoadBuild(b)}
                      className="rounded-md border border-[#DCDEE2] bg-white px-2.5 py-1 text-xs font-medium text-[#141517] hover:bg-[#F7F7F5]"
                    >
                      Laden
                    </button>
                    <button
                      type="button"
                      onClick={() => onDeleteBuild(b.id)}
                      aria-label={`${b.name} löschen`}
                      className="rounded-md p-1 text-[#5C6068] hover:text-[#B91C1C]"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {buildA && buildB && (
          <div className="mt-4 rounded-lg border border-[#E4E5E7] bg-[#FAFAFA] p-4 text-xs">
            <div className="font-display font-bold text-[#141517] mb-2">
              Direktvergleich: {buildA.name} vs. {buildB.name}
            </div>
            <div className="grid grid-cols-3 gap-2 border-b border-[#E4E5E7] pb-2 font-semibold text-[#5C6068]">
              <div>Merkmal</div>
              <div>{buildA.name}</div>
              <div>{buildB.name}</div>
            </div>
            <div className="divide-y divide-[#E4E5E7]">
              <div className="grid grid-cols-3 gap-2 py-2">
                <div className="text-[#5C6068]">Gesamtpreis brutto</div>
                <div className="font-mono-tabular font-semibold">{formatEuro(buildA.totalBrutto)}</div>
                <div className="font-mono-tabular font-semibold">{formatEuro(buildB.totalBrutto)}</div>
              </div>
              <div className="grid grid-cols-3 gap-2 py-2">
                <div className="text-[#5C6068]">Gesamtpreis netto</div>
                <div className="font-mono-tabular">{formatEuro(buildA.totalNetto)}</div>
                <div className="font-mono-tabular">{formatEuro(buildB.totalNetto)}</div>
              </div>
              <div className="grid grid-cols-3 gap-2 py-2">
                <div className="text-[#5C6068]">Extras gewählt</div>
                <div className="font-mono-tabular">{buildA.config.selectedOptionIds.length} Optionen</div>
                <div className="font-mono-tabular">{buildB.config.selectedOptionIds.length} Optionen</div>
              </div>
              <div className="grid grid-cols-3 gap-2 py-2">
                <div className="text-[#5C6068]">Preisdifferenz</div>
                <div className="col-span-2 font-mono-tabular font-semibold text-[#141517]">
                  {formatEuro(Math.abs(buildA.totalBrutto - buildB.totalBrutto))} Unterschied
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Included Standard Equipment Overview */}
      <div className="no-print rounded-xl border border-[#E4E5E7] bg-white p-5 text-xs">
        <h3 className="font-display text-sm font-bold text-[#141517] mb-3">
          Enthaltene Serienausstattung ({trim.name})
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[#4B4F56]">
          <div>
            <div className="font-semibold text-[#141517] mb-1">Linien-Highlights ({trim.name})</div>
            <ul className="space-y-1">
              {[
                ...trim.standardFeatures.sicherheit,
                ...trim.standardFeatures.infotainment,
                ...trim.standardFeatures.komfort,
              ].map((item) => (
                <li key={item}>· {item}</li>
              ))}
            </ul>
          </div>
          <div>
            <div className="font-semibold text-[#141517] mb-1">Allgemeine Serienausstattung</div>
            <ul className="space-y-1">
              {GENERAL_STANDARD_EQUIPMENT.sicherheit.slice(0, 8).map((item) => (
                <li key={item}>· {item}</li>
              ))}
              {engine.isEcoFlex && (
                <li className="font-medium text-[#15803D]">
                  · Inkl. komplettem ecoFLEX-Aerodynamik- & Sparpaket
                </li>
              )}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
