import React from 'react';
import imgLimo4 from '../assets/images/insignia_limousine_4d_1794576257409.jpg';
import imgLimo5 from '../assets/images/insignia_limousine_5d_1794576257351.jpg';
import imgTourer from '../assets/images/insignia_sports_tourer_1794576258296.jpg';
import imgInterior from '../assets/images/insignia_interior_2010_1794576259355.jpg';
import {
  BodyStyleSpec,
  EngineSpec,
  PaintColor,
  PriceMode,
  SeatPackageOption,
  StudioView,
  TrimLineInfo,
  WheelOption,
} from '../types/configurator';
import { formatEuro } from '../utils/configEngine';
import { Car, Eye, FileText, Ruler } from 'lucide-react';

interface StudioStageProps {
  body: BodyStyleSpec;
  trim: TrimLineInfo;
  engine: EngineSpec;
  paint: PaintColor;
  seatPkg: SeatPackageOption;
  interiorColor: string;
  wheel: WheelOption | undefined;
  totalBrutto: number;
  totalNetto: number;
  effectiveTrunkL: number;
  trunkReduction: number;
  priceMode: PriceMode;
  onChangePriceMode: (mode: PriceMode) => void;
  studioView: StudioView;
  onChangeStudioView: (view: StudioView) => void;
  perf: {
    topSpeedKmh: number;
    topSpeedLimited?: boolean;
    accel0100: number;
    consumptionCombined: number;
    co2Combined: number;
  };
  onOpenPriceListPdf: () => void;
}

export const StudioStage: React.FC<StudioStageProps> = ({
  body,
  trim,
  engine,
  paint,
  seatPkg,
  interiorColor,
  wheel,
  totalBrutto,
  totalNetto,
  effectiveTrunkL,
  trunkReduction,
  priceMode,
  onChangePriceMode,
  studioView,
  onChangeStudioView,
  perf,
  onOpenPriceListPdf,
}) => {
  const exteriorImg =
    body.id === 'limo4' ? imgLimo4 : body.id === 'limo5' ? imgLimo5 : imgTourer;
  const displayTotal = priceMode === 'brutto' ? totalBrutto : totalNetto;

  return (
    <div className="lg:sticky lg:top-20 flex flex-col gap-4">
      {/* Workspace Toolbar above Visual Stage */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 rounded-lg bg-[#EAEBE8] p-1">
          <button
            type="button"
            onClick={() => onChangeStudioView('exterior')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              studioView === 'exterior'
                ? 'bg-white text-[#141517] shadow-xs'
                : 'text-[#5C6068] hover:text-[#141517]'
            }`}
          >
            <Car className="h-3.5 w-3.5" aria-hidden="true" />
            Exterieur
          </button>
          <button
            type="button"
            onClick={() => onChangeStudioView('interior')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              studioView === 'interior'
                ? 'bg-white text-[#141517] shadow-xs'
                : 'text-[#5C6068] hover:text-[#141517]'
            }`}
          >
            <Eye className="h-3.5 w-3.5" aria-hidden="true" />
            Cockpit
          </button>
          <button
            type="button"
            onClick={() => onChangeStudioView('dimensions')}
            className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              studioView === 'dimensions'
                ? 'bg-white text-[#141517] shadow-xs'
                : 'text-[#5C6068] hover:text-[#141517]'
            }`}
          >
            <Ruler className="h-3.5 w-3.5" aria-hidden="true" />
            Maße & Gepäckraum
          </button>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-lg bg-[#EAEBE8] p-1">
            <button
              type="button"
              onClick={() => onChangePriceMode('brutto')}
              className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                priceMode === 'brutto'
                  ? 'bg-white text-[#141517] shadow-xs'
                  : 'text-[#5C6068] hover:text-[#141517]'
              }`}
            >
              inkl. MwSt.
            </button>
            <button
              type="button"
              onClick={() => onChangePriceMode('netto')}
              className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                priceMode === 'netto'
                  ? 'bg-white text-[#141517] shadow-xs'
                  : 'text-[#5C6068] hover:text-[#141517]'
              }`}
            >
              ohne MwSt.
            </button>
          </div>
          <button
            type="button"
            onClick={onOpenPriceListPdf}
            className="flex items-center gap-1.5 rounded-lg border border-[#DCDEE2] bg-white px-3 py-1.5 text-xs font-medium text-[#141517] transition-colors hover:bg-[#F2F3F0] whitespace-nowrap shrink-0"
          >
            <FileText className="h-3.5 w-3.5 text-[#5C6068]" aria-hidden="true" />
            Preisliste 06/2010
          </button>
        </div>
      </div>

      {/* Main Visual Showcase */}
      <div className="overflow-hidden rounded-xl border border-[#E4E5E7] bg-white">
        {studioView === 'dimensions' ? (
          <div className="p-6 bg-[#FAFAFA]">
            <div className="flex items-baseline justify-between mb-4">
              <div>
                <h3 className="font-display text-base font-bold text-[#141517]">
                  Fahrzeugabmessungen & Gepäckraum ({body.shortName})
                </h3>
                <p className="text-xs text-[#5C6068]">
                  Angaben in mm bzw. Liter nach ECIE-Messmethode (Stand Preisliste 21.06.2010)
                </p>
              </div>
            </div>

            {/* Technical Side & Front Wireframe Diagram */}
            <div className="rounded-lg border border-[#E4E5E7] bg-white p-4 mb-4">
              <svg
                viewBox="0 0 680 190"
                className="w-full h-auto text-[#141517]"
                role="img"
                aria-label={`Maßzeichnung ${body.name}`}
              >
                {/* Ground line */}
                <line x1="20" y1="145" x2="430" y2="145" stroke="#D1D5DB" strokeWidth="1" />
                {/* Silhouette */}
                {body.id === 'tourer' ? (
                  <path
                    d="M 55 128 L 58 102 L 105 90 L 185 55 L 355 52 L 398 85 L 402 128 Z"
                    fill="#F3F4F6"
                    stroke="#141517"
                    strokeWidth="2"
                    strokeLinejoin="round"
                  />
                ) : body.id === 'limo5' ? (
                  <path
                    d="M 55 128 L 58 102 L 110 90 L 185 56 L 310 56 L 385 95 L 395 128 Z"
                    fill="#F3F4F6"
                    stroke="#141517"
                    strokeWidth="2"
                    strokeLinejoin="round"
                  />
                ) : (
                  <path
                    d="M 55 128 L 58 102 L 110 90 L 185 56 L 295 56 L 350 92 L 395 96 L 395 128 Z"
                    fill="#F3F4F6"
                    stroke="#141517"
                    strokeWidth="2"
                    strokeLinejoin="round"
                  />
                )}
                {/* Roof rails for Sports Tourer */}
                {body.id === 'tourer' && (
                  <path d="M 192 50 L 352 48" stroke="#6B7280" strokeWidth="2.5" strokeLinecap="round" />
                )}
                {/* Wheels */}
                <circle cx="122" cy="128" r="21" fill="#FFFFFF" stroke="#141517" strokeWidth="2.5" />
                <circle cx="122" cy="128" r="10" fill="none" stroke="#6B7280" strokeWidth="1.5" />
                <circle cx="332" cy="128" r="21" fill="#FFFFFF" stroke="#141517" strokeWidth="2.5" />
                <circle cx="332" cy="128" r="10" fill="none" stroke="#6B7280" strokeWidth="1.5" />

                {/* Wheelbase dimension */}
                <line x1="122" y1="158" x2="332" y2="158" stroke="#D99B00" strokeWidth="1.5" />
                <line x1="122" y1="152" x2="122" y2="164" stroke="#D99B00" strokeWidth="1.5" />
                <line x1="332" y1="152" x2="332" y2="164" stroke="#D99B00" strokeWidth="1.5" />
                <text x="227" y="172" textAnchor="middle" className="text-[11px] font-mono fill-[#141517] font-semibold">
                  Radstand {body.wheelbaseMm} mm
                </text>

                {/* Overall Length */}
                <line x1="55" y1="180" x2={body.id === 'tourer' ? 402 : 395} y2="180" stroke="#141517" strokeWidth="1.2" />
                <text x="228" y="34" textAnchor="middle" className="text-[11px] font-mono fill-[#141517] font-semibold">
                  Gesamtlänge {body.lengthMm} mm
                </text>
                <line x1="55" y1="40" x2={body.id === 'tourer' ? 402 : 395} y2="40" stroke="#9CA3AF" strokeWidth="1" strokeDasharray="3 3" />

                {/* Height dimension */}
                <line x1="422" y1="52" x2="422" y2="145" stroke="#141517" strokeWidth="1.2" />
                <text x="430" y="102" className="text-[11px] font-mono fill-[#141517] font-semibold">
                  {body.heightMm} mm
                </text>

                {/* Front Width Schematic */}
                <rect x="520" y="65" width="120" height="62" rx="14" fill="#F3F4F6" stroke="#141517" strokeWidth="2" />
                <rect x="530" y="127" width="18" height="16" rx="2" fill="#141517" />
                <rect x="612" y="127" width="18" height="16" rx="2" fill="#141517" />
                <path d="M 505 80 L 520 80 M 640 80 L 655 80" stroke="#141517" strokeWidth="2.5" strokeLinecap="round" />
                <text x="580" y="48" textAnchor="middle" className="text-[10px] font-mono fill-[#5C6068]">
                  ohne Spiegel: {body.widthWithoutMirrorsMm} mm
                </text>
                <text x="580" y="164" textAnchor="middle" className="text-[11px] font-mono fill-[#141517] font-semibold">
                  mit Spiegeln: {body.widthWithMirrorsMm} mm
                </text>
                <text x="580" y="179" textAnchor="middle" className="text-[10px] font-mono fill-[#5C6068]">
                  Spur v/h: {body.trackFrontMm} / {body.trackRearMm} mm
                </text>
              </svg>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
              <div className="rounded-lg border border-[#E4E5E7] bg-white p-3">
                <div className="text-[#5C6068]">Kofferraum (aktuell)</div>
                <div className="mt-1 font-mono-tabular text-base font-semibold text-[#141517]">
                  {effectiveTrunkL} l
                </div>
                {trunkReduction > 0 && (
                  <div className="mt-0.5 text-[11px] text-[#B45309]">
                    −{trunkReduction} l (Notrad/Infinity)
                  </div>
                )}
              </div>
              <div className="rounded-lg border border-[#E4E5E7] bg-white p-3">
                <div className="text-[#5C6068]">Ladevolumen max.</div>
                <div className="mt-1 font-mono-tabular text-base font-semibold text-[#141517]">
                  {body.trunkVolumeFoldedRoofL ?? body.trunkVolumeFoldedWindowL} l
                </div>
                <div className="mt-0.5 text-[11px] text-[#5C6068]">
                  {body.trunkVolumeFoldedRoofL ? 'bis unters Dach' : 'bis Oberkante Lehne'}
                </div>
              </div>
              <div className="rounded-lg border border-[#E4E5E7] bg-white p-3">
                <div className="text-[#5C6068]">Leergewicht / Zuladung</div>
                <div className="mt-1 font-mono-tabular text-base font-semibold text-[#141517]">
                  {body.curbWeightKg} / {body.payloadKg} kg
                </div>
                <div className="mt-0.5 text-[11px] text-[#5C6068]">
                  zGG: {body.grossWeightKg} kg
                </div>
              </div>
              <div className="rounded-lg border border-[#E4E5E7] bg-white p-3">
                <div className="text-[#5C6068]">Wendekreis</div>
                <div className="mt-1 font-mono-tabular text-base font-semibold text-[#141517]">
                  {body.turningCircleWallM} m
                </div>
                <div className="mt-0.5 text-[11px] text-[#5C6068]">
                  Bordstein: {body.turningCircleCurbM} m
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="relative aspect-16/9 w-full bg-[#EDEDEB]">
            <img
              src={studioView === 'interior' ? imgInterior : exteriorImg}
              alt={
                studioView === 'interior'
                  ? 'Opel Insignia A Cockpit und Innenraum'
                  : `${body.name} in ${paint.name}`
              }
              referrerPolicy="no-referrer"
              className="h-full w-full object-cover transition-opacity duration-200"
            />
            <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 via-black/35 to-transparent p-5 text-white">
              <div className="flex flex-wrap items-end justify-between gap-3">
                <div>
                  <div className="text-xs font-medium text-white/80">
                    {body.name} · {trim.name} · Stand 21.06.2010
                  </div>
                  <div className="font-display text-xl font-bold tracking-tight">
                    {engine.name} ({engine.kw} kW / {engine.ps} PS)
                  </div>
                </div>
                <div className="flex items-center gap-2.5 rounded-lg bg-black/45 px-3 py-1.5 backdrop-blur-xs border border-white/15">
                  <span
                    className="h-4 w-4 rounded-sm border border-white/50 shrink-0"
                    style={{ backgroundColor: paint.hex }}
                    aria-hidden="true"
                  />
                  <span className="text-xs font-medium text-white whitespace-nowrap">
                    {paint.name}
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Active Spec Ribbon */}
        <div className="grid grid-cols-2 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x divide-[#E4E5E7] border-t border-[#E4E5E7] bg-white">
          <div className="p-3.5">
            <div className="text-[11px] font-medium text-[#5C6068]">
              {priceMode === 'brutto' ? 'Gesamtpreis (inkl. MwSt.)' : 'Gesamtpreis (ohne MwSt.)'}
            </div>
            <div className="mt-0.5 font-mono-tabular text-lg font-semibold text-[#141517]">
              {formatEuro(displayTotal)}
            </div>
          </div>
          <div className="p-3.5">
            <div className="text-[11px] font-medium text-[#5C6068]">Antrieb & Getriebe</div>
            <div className="mt-0.5 font-mono-tabular text-sm font-semibold text-[#141517] truncate">
              {engine.kw} kW ({engine.ps} PS)
            </div>
            <div className="text-[11px] text-[#5C6068] truncate">{engine.transmission}</div>
          </div>
          <div className="p-3.5">
            <div className="text-[11px] font-medium text-[#5C6068]">Verbrauch / CO₂ komb.</div>
            <div className="mt-0.5 font-mono-tabular text-sm font-semibold text-[#141517]">
              {perf.consumptionCombined.toFixed(1).replace('.', ',')} l/100km
            </div>
            <div className="font-mono-tabular text-[11px] text-[#5C6068]">
              {perf.co2Combined} g/km · {engine.emissionStandard}
            </div>
          </div>
          <div className="p-3.5">
            <div className="text-[11px] font-medium text-[#5C6068]">Räder & Interieur</div>
            <div className="mt-0.5 text-sm font-semibold text-[#141517] truncate">
              {wheel ? `${wheel.sizeInches}" (${wheel.code})` : trim.wheelsLabel}
            </div>
            <div className="text-[11px] text-[#5C6068] truncate">
              {seatPkg.id === 'STD' ? trim.seatsLabel : seatPkg.name} · {interiorColor}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
