import React from 'react';
import { ENGINES, PAINT_COLORS, SEAT_PACKAGES, TRIM_LINES, WHEELS } from '../data/insignia2010';
import { ConfigurationState, PriceMode } from '../types/configurator';
import { formatEuro } from '../utils/configEngine';
import { Check } from 'lucide-react';

interface StepExterieurInterieurProps {
  state: ConfigurationState;
  priceMode: PriceMode;
  onSelectPaint: (paintId: string) => void;
  onSelectSeatPackage: (seatPkgId: string) => void;
  onSelectInteriorColor: (color: ConfigurationState['interiorColor']) => void;
  onSelectDecor: (decorId: ConfigurationState['decorId']) => void;
  onSelectWheel: (wheelId: string) => void;
  onNext: () => void;
}

export const StepExterieurInterieur: React.FC<StepExterieurInterieurProps> = ({
  state,
  priceMode,
  onSelectPaint,
  onSelectSeatPackage,
  onSelectInteriorColor,
  onSelectDecor,
  onSelectWheel,
  onNext,
}) => {
  const activeSeat = SEAT_PACKAGES.find((s) => s.id === state.seatPackageId) || SEAT_PACKAGES[0];
  const activeEngine = ENGINES.find((e) => e.id === state.engineId);
  const isSt4x4 = state.bodyStyle === 'tourer' && Boolean(activeEngine?.is4x4);

  const uniColors = PAINT_COLORS.filter((p) => p.type === 'Uni');
  const metallicColors = PAINT_COLORS.filter((p) => p.type !== 'Uni');

  const availableSeats = SEAT_PACKAGES.filter((s) => Boolean(s.prices[state.trim]));
  const availableWheels = WHEELS.filter((w) => {
    if (!w.prices[state.trim]) return false;
    if (w.id === 'Q00' && isSt4x4) return false;
    // If Premium Package forces a specific wheel size, filter or mark clearly
    return true;
  });

  const canSelectBeige =
    activeSeat.hasBeigeOption &&
    (state.trim === 'edition' || state.trim === 'innovation') &&
    !state.selectedOptionIds.includes('XK0') &&
    !state.selectedOptionIds.includes('PHLC_SPORT_EDITION');

  const isNappa = activeSeat.id.includes('NAPPA') || activeSeat.id.includes('TAFR');

  return (
    <div className="flex flex-col gap-8">
      {/* 1. Lackierung */}
      <section aria-labelledby="heading-paint">
        <div className="mb-4">
          <h2 id="heading-paint" className="font-display text-xl font-bold text-[#141517]">
            04. Außenlackierung wählen
          </h2>
          <p className="mt-1 text-sm text-[#5C6068]">
            Uni-Lackierungen ohne Aufpreis; Zweischicht-Metallic, Mineraleffekt und Perleffekt{' '}
            {formatEuro(priceMode === 'brutto' ? 525 : 441.18)}.
          </p>
        </div>

        <div className="space-y-4">
          <div>
            <div className="mb-2 text-xs font-semibold text-[#5C6068]">Uni-Lackierungen (Serie)</div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {uniColors.map((paint) => {
                const isSelected = state.paintId === paint.id;
                return (
                  <button
                    key={paint.id}
                    type="button"
                    onClick={() => onSelectPaint(paint.id)}
                    className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-all ${
                      isSelected
                        ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                        : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                    }`}
                  >
                    <span
                      className="h-9 w-9 rounded-lg border border-black/15 shrink-0"
                      style={{
                        background: `linear-gradient(135deg, ${paint.hex} 0%, ${paint.accentHex} 100%)`,
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-[#141517] truncate">
                        {paint.name}
                      </div>
                      <div className="text-[11px] font-mono-tabular text-[#5C6068]">
                        {paint.code} · Serie
                      </div>
                    </div>
                    {isSelected && <Check className="h-4 w-4 text-[#D99B00] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="mb-2 text-xs font-semibold text-[#5C6068]">
              Zweischicht-Metallic, Mineraleffekt & Perleffekt (+
              {formatEuro(priceMode === 'brutto' ? 525 : 441.18)})
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {metallicColors.map((paint) => {
                const isSelected = state.paintId === paint.id;
                const price = priceMode === 'brutto' ? paint.price.brutto : paint.price.netto;
                return (
                  <button
                    key={paint.id}
                    type="button"
                    onClick={() => onSelectPaint(paint.id)}
                    className={`flex items-center gap-3 rounded-xl border p-3 text-left transition-all ${
                      isSelected
                        ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                        : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                    }`}
                  >
                    <span
                      className="h-9 w-9 rounded-lg border border-black/15 shrink-0"
                      style={{
                        background: `linear-gradient(135deg, ${paint.hex} 0%, ${paint.accentHex} 100%)`,
                      }}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold text-[#141517] truncate">
                        {paint.name}
                      </div>
                      <div className="text-[11px] font-mono-tabular text-[#5C6068]">
                        {paint.code} · +{formatEuro(price)}
                      </div>
                    </div>
                    {isSelected && <Check className="h-4 w-4 text-[#D99B00] shrink-0" />}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* 2. Sitze, Leder & Premium-Pakete */}
      <section aria-labelledby="heading-seats">
        <div className="mb-4">
          <h2 id="heading-seats" className="font-display text-xl font-bold text-[#141517]">
            05. Sitze, Polster & Premium-Pakete
          </h2>
          <p className="mt-1 text-sm text-[#5C6068]">
            Von AGR-Ergonomiesitzen bis zur Volllederausstattung Fine Nappaleder Indian Summer oder
            OPC Line Recaro.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-2.5">
          {availableSeats.map((seat) => {
            const isSelected = state.seatPackageId === seat.id;
            const priceObj = seat.prices[state.trim]!;
            const price = priceMode === 'brutto' ? priceObj.brutto : priceObj.netto;

            return (
              <button
                key={seat.id}
                type="button"
                onClick={() => onSelectSeatPackage(seat.id)}
                className={`rounded-xl border p-4 text-left transition-all ${
                  isSelected
                    ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                    : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                }`}
              >
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono-tabular text-xs font-semibold text-[#5C6068]">
                      {seat.code}
                    </span>
                    <span className="font-display text-sm font-bold text-[#141517]">
                      {seat.name}
                    </span>
                    {isSelected && <Check className="h-4 w-4 text-[#D99B00]" />}
                  </div>
                  <span className="font-mono-tabular text-sm font-semibold text-[#141517]">
                    {price === 0 ? 'Serie' : `+${formatEuro(price)}`}
                  </span>
                </div>
                <div className="mt-1 text-xs text-[#5C6068]">{seat.subtitle}</div>
                <ul className="mt-2 space-y-1 text-xs text-[#4B4F56]">
                  {seat.details.map((d) => (
                    <li key={d}>· {d}</li>
                  ))}
                </ul>
              </button>
            );
          })}
        </div>

        {/* Interior Color & Decor Selector */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 rounded-xl border border-[#E4E5E7] bg-white p-4">
          <div>
            <div className="text-xs font-semibold text-[#141517] mb-2">Innenraumfarbe</div>
            {isNappa ? (
              <div className="rounded-lg border border-[#141517] bg-[#F7F7F5] px-3 py-2 text-xs font-medium text-[#141517]">
                Indian Summer (Cognac-Nappaleder mit Cashmere-Ziernähten)
              </div>
            ) : (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => onSelectInteriorColor('Schwarz')}
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-colors ${
                    state.interiorColor === 'Schwarz'
                      ? 'border-[#141517] bg-[#141517] text-white'
                      : 'border-[#DCDEE2] bg-white text-[#141517] hover:bg-[#F7F7F5]'
                  }`}
                >
                  Schwarz / Anthrazit
                </button>
                <button
                  type="button"
                  disabled={!canSelectBeige}
                  onClick={() => canSelectBeige && onSelectInteriorColor('Beige')}
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-colors ${
                    !canSelectBeige
                      ? 'border-[#E4E5E7] bg-[#F7F7F5] text-[#9CA3AF] cursor-not-allowed'
                      : state.interiorColor === 'Beige'
                      ? 'border-[#141517] bg-[#141517] text-white'
                      : 'border-[#DCDEE2] bg-white text-[#141517] hover:bg-[#F7F7F5]'
                  }`}
                >
                  Beige {!canSelectBeige && '(n. v.)'}
                </button>
              </div>
            )}
          </div>

          <div>
            <div className="text-xs font-semibold text-[#141517] mb-2">Dekorleisten</div>
            {state.trim === 'innovation' && state.interiorColor !== 'Beige' ? (
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => onSelectDecor('kibo_holz')}
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-colors ${
                    state.decorId === 'kibo_holz'
                      ? 'border-[#141517] bg-[#141517] text-white'
                      : 'border-[#DCDEE2] bg-white text-[#141517] hover:bg-[#F7F7F5]'
                  }`}
                >
                  Kibo Holzdesign
                </button>
                <button
                  type="button"
                  onClick={() => onSelectDecor('klavierlack')}
                  className={`flex-1 rounded-lg border px-3 py-2 text-xs font-medium transition-colors ${
                    state.decorId === 'klavierlack'
                      ? 'border-[#141517] bg-[#141517] text-white'
                      : 'border-[#DCDEE2] bg-white text-[#141517] hover:bg-[#F7F7F5]'
                  }`}
                >
                  Klavierlack
                </button>
              </div>
            ) : (
              <div className="rounded-lg border border-[#E4E5E7] bg-[#F7F7F5] px-3 py-2 text-xs text-[#4B4F56]">
                {TRIM_LINES[state.trim].decorLabel} (Seriendekor für {TRIM_LINES[state.trim].name})
              </div>
            )}
          </div>
        </div>
      </section>

      {/* 3. Räder & Felgen */}
      <section aria-labelledby="heading-wheels">
        <div className="mb-4">
          <h2 id="heading-wheels" className="font-display text-xl font-bold text-[#141517]">
            06. Räder & Leichtmetallfelgen
          </h2>
          <p className="mt-1 text-sm text-[#5C6068]">
            {activeSeat.includedWheelInches
              ? `Durch Ihr gewähltes Premium-Paket sind ${activeSeat.includedWheelInches}" Leichtmetallräder bereits im Paketpreis enthalten.`
              : `Alle für ${TRIM_LINES[state.trim].name} verfügbaren Räder von 16" bis 20".`}
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {availableWheels.map((wheel) => {
            const isSelected = state.wheelId === wheel.id;
            const trimPrice = wheel.prices[state.trim];
            const forcedByPremium =
              activeSeat.includedWheelInches !== undefined &&
              wheel.sizeInches !== activeSeat.includedWheelInches;
            const includedByPremium =
              activeSeat.includedWheelInches !== undefined &&
              wheel.sizeInches === activeSeat.includedWheelInches;

            let priceLabel = 'Serie';
            if (includedByPremium) {
              priceLabel = 'Im Premium-Paket';
            } else if (trimPrice === 'OHNE_MEHRPREIS') {
              priceLabel = 'ohne Mehrpreis';
            } else if (trimPrice && typeof trimPrice === 'object') {
              priceLabel = `+${formatEuro(
                priceMode === 'brutto' ? trimPrice.brutto : trimPrice.netto
              )}`;
            }

            return (
              <button
                key={wheel.id}
                type="button"
                disabled={forcedByPremium}
                onClick={() => !forcedByPremium && onSelectWheel(wheel.id)}
                className={`flex flex-col justify-between rounded-xl border p-4 text-left transition-all ${
                  forcedByPremium
                    ? 'border-[#E4E5E7] bg-[#FAFAFA] opacity-50 cursor-not-allowed'
                    : isSelected
                    ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                    : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                }`}
              >
                <div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-mono-tabular text-xs font-semibold text-[#5C6068]">
                      {wheel.sizeInches}" · {wheel.code}
                    </span>
                    <span className="font-mono-tabular text-xs font-semibold text-[#141517]">
                      {priceLabel}
                    </span>
                  </div>
                  <div className="mt-1 flex items-center justify-between gap-2">
                    <div className="font-display text-sm font-bold text-[#141517]">
                      {wheel.name}
                    </div>
                    {isSelected && <Check className="h-4 w-4 text-[#D99B00] shrink-0" />}
                  </div>
                  <p className="mt-1 text-xs text-[#5C6068]">{wheel.description}</p>
                </div>

                <div className="mt-3 pt-2 border-t border-[#F0F1F3] font-mono-tabular text-[11px] text-[#5C6068]">
                  Bereifung: {wheel.tireSpec}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      <div className="flex justify-end pt-2">
        <button
          type="button"
          onClick={onNext}
          className="rounded-lg bg-[#141517] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#2A2D32]"
        >
          Weiter zu Paketen & Sonderausstattung
        </button>
      </div>
    </div>
  );
};
