import React from 'react';
import { X } from 'lucide-react';

interface PriceListModalProps {
  open: boolean;
  onClose: () => void;
}

export const PriceListModal: React.FC<PriceListModalProps> = ({ open, onClose }) => {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pdf-modal-title"
    >
      <div className="flex h-[88vh] w-full max-w-5xl flex-col overflow-hidden rounded-xl bg-white shadow-xl">
        <div className="flex items-center justify-between border-b border-[#E4E5E7] px-5 py-3.5">
          <div>
            <h2 id="pdf-modal-title" className="font-display text-base font-bold text-[#141517]">
              Original-Preisliste: OPEL Insignia & Sports Tourer (21. Juni 2010)
            </h2>
            <p className="text-xs text-[#5C6068]">
              Best.-Nr.: 01/04030/1001 · ADAM OPEL GmbH, Rüsselsheim
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Preisliste schließen"
            className="rounded-lg p-2 text-[#5C6068] hover:bg-[#F2F3F0] hover:text-[#141517] transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 bg-[#F2F3F0]">
          <iframe
            src="/assets/aistudio/Insignia-A-2010-06-21_ab51b7a2.pdf"
            title="Opel Insignia Preisliste 21. Juni 2010"
            className="h-full w-full border-0"
          />
        </div>
      </div>
    </div>
  );
};
