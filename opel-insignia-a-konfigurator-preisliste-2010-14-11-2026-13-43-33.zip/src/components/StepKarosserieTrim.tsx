import React, { useState } from 'react';
import {
  AWARDS_2009_2010,
  BODY_STYLES,
  ENGINES,
  GENERAL_STANDARD_EQUIPMENT,
  TRIM_LINES,
} from '../data/insignia2010';
import { BodyStyleId, PriceMode, TrimId } from '../types/configurator';
import { formatEuro } from '../utils/configEngine';
import { Check, ChevronDown, ChevronUp } from 'lucide-react';

interface StepKarosserieTrimProps {
  bodyStyle: BodyStyleId;
  trim: TrimId;
  priceMode: PriceMode;
  onSelectBodyStyle: (id: BodyStyleId) => void;
  onSelectTrim: (id: TrimId) => void;
  onNext: () => void;
}

const BODY_ORDER: BodyStyleId[] = ['limo4', 'limo5', 'tourer'];
const TRIM_ORDER: TrimId[] = ['selection', 'edition', 'sport', 'innovation'];

function getMinTrimPrice(bodyStyle: BodyStyleId, trim: TrimId, priceMode: PriceMode): number {
  const prices = ENGINES.map((e) => e.prices[bodyStyle]?.[trim])
    .filter((p): p is { brutto: number; netto: number } => Boolean(p))
    .map((p) => (priceMode === 'brutto' ? p.brutto : p.netto));
  return Math.min(...prices);
}

export const StepKarosserieTrim: React.FC<StepKarosserieTrimProps> = ({
  bodyStyle,
  trim,
  priceMode,
  onSelectBodyStyle,
  onSelectTrim,
  onNext,
}) => {
  const [showSerienDetails, setShowSerienDetails] = useState(false);
  const [serienTab, setSerienTab] = useState<'vergleich' | 'allgemein' | 'ecoflex' | 'awards'>(
    'vergleich'
  );

  return (
    <div className="flex flex-col gap-8">
      {/* 1. Karosserieform */}
      <section aria-labelledby="heading-karosserie">
        <div className="mb-4">
          <h2 id="heading-karosserie" className="font-display text-xl font-bold text-[#141517]">
            01. Karosserieform wählen
          </h2>
          <p className="mt-1 text-sm text-[#5C6068]">
            Drei Karosserievarianten auf Basis der Opel Insignia Preisliste vom 21. Juni 2010.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {BODY_ORDER.map((id) => {
            const spec = BODY_STYLES[id];
            const isSelected = bodyStyle === id;
            const startPrice = getMinTrimPrice(id, 'selection', priceMode);
            return (
              <button
                key={id}
                type="button"
                onClick={() => onSelectBodyStyle(id)}
                className={`flex flex-col justify-between rounded-xl border p-4 text-left transition-all ${
                  isSelected
                    ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                    : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-display text-sm font-bold text-[#141517]">
                      {spec.shortName}
                    </span>
                    {isSelected && <Check className="h-4 w-4 text-[#D99B00] shrink-0" />}
                  </div>
                  <div className="mt-0.5 text-xs text-[#5C6068]">{spec.subtitle}</div>
                  <p className="mt-2.5 text-xs leading-relaxed text-[#4B4F56]">
                    {spec.description}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-[#F0F1F3] flex items-baseline justify-between text-xs">
                  <span className="font-mono-tabular text-[#5C6068]">
                    {spec.lengthMm} mm · {spec.trunkVolumeStandardL} l
                  </span>
                  <span className="font-mono-tabular font-semibold text-[#141517]">
                    ab {formatEuro(startPrice)}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* 2. Ausstattungslinie */}
      <section aria-labelledby="heading-trim">
        <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
          <div>
            <h2 id="heading-trim" className="font-display text-xl font-bold text-[#141517]">
              02. Ausstattungslinie wählen
            </h2>
            <p className="mt-1 text-sm text-[#5C6068]">
              Alle vier Modelllinien mit individueller Serienausstattung.
            </p>
          </div>
          <button
            type="button"
            onClick={() => setShowSerienDetails((v) => !v)}
            className="flex items-center gap-1.5 rounded-lg border border-[#DCDEE2] bg-white px-3 py-1.5 text-xs font-medium text-[#141517] hover:bg-[#F2F3F0] transition-colors whitespace-nowrap shrink-0"
          >
            Serienausstattung im Detail
            {showSerienDetails ? (
              <ChevronUp className="h-3.5 w-3.5" />
            ) : (
              <ChevronDown className="h-3.5 w-3.5" />
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {TRIM_ORDER.map((id) => {
            const info = TRIM_LINES[id];
            const isSelected = trim === id;
            const minPrice = getMinTrimPrice(bodyStyle, id, priceMode);

            return (
              <button
                key={id}
                type="button"
                onClick={() => onSelectTrim(id)}
                className={`flex flex-col justify-between rounded-xl border p-4 text-left transition-all ${
                  isSelected
                    ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                    : 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                }`}
              >
                <div>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-display text-base font-bold text-[#141517]">
                      {info.name}
                    </span>
                    <span className="font-mono-tabular text-sm font-semibold text-[#141517]">
                      ab {formatEuro(minPrice)}
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-[#5C6068]">{info.tagline}</p>

                  <ul className="mt-3 space-y-1.5 text-xs text-[#2C2F34]">
                    {info.highlights.map((h) => (
                      <li key={h} className="flex items-start gap-2">
                        <Check
                          className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${
                            isSelected ? 'text-[#D99B00]' : 'text-[#8A8F98]'
                          }`}
                          aria-hidden="true"
                        />
                        <span>{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-4 pt-3 border-t border-[#F0F1F3] grid grid-cols-2 gap-2 text-[11px] text-[#5C6068]">
                  <div className="truncate">Räder: {info.wheelsLabel}</div>
                  <div className="truncate">Klima: {info.climateLabel}</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Expandable Full Standard Equipment Matrix (Pages 10–13) */}
        {showSerienDetails && (
          <div className="mt-4 rounded-xl border border-[#E4E5E7] bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-[#E4E5E7]">
              <div>
                <h3 className="font-display text-base font-bold text-[#141517]">
                  Vollständige Serienausstattung (Seiten 10–13 der Preisliste)
                </h3>
                <p className="text-xs text-[#5C6068]">
                  Direkter Vergleich aller vier Ausstattungslinien sowie allgemeine & ecoFLEX-Serienumfänge.
                </p>
              </div>
              <div className="flex items-center gap-1 rounded-lg bg-[#EAEBE8] p-1">
                {(
                  [
                    { id: 'vergleich', label: 'Linien-Vergleich' },
                    { id: 'allgemein', label: 'Allgemeine Serie' },
                    { id: 'ecoflex', label: 'ecoFLEX' },
                    { id: 'awards', label: 'Auszeichnungen' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setSerienTab(tab.id)}
                    className={`rounded-md px-2.5 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                      serienTab === tab.id
                        ? 'bg-white text-[#141517] shadow-xs'
                        : 'text-[#5C6068] hover:text-[#141517]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {serienTab === 'vergleich' && (
              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-[#E4E5E7] text-[#5C6068]">
                      <th className="py-2 pr-3 font-semibold w-36">Merkmal</th>
                      {TRIM_ORDER.map((tid) => (
                        <th
                          key={tid}
                          className={`py-2 px-3 font-semibold ${
                            tid === trim ? 'text-[#141517] bg-[#F7F7F5]' : ''
                          }`}
                        >
                          {TRIM_LINES[tid].name}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#F0F1F3]">
                    <tr>
                      <td className="py-2.5 pr-3 font-medium text-[#141517]">Infotainment</td>
                      {TRIM_ORDER.map((tid) => (
                        <td key={tid} className={`py-2.5 px-3 ${tid === trim ? 'bg-[#F7F7F5]' : ''}`}>
                          {TRIM_LINES[tid].infotainmentLabel}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-2.5 pr-3 font-medium text-[#141517]">Klimatisierung</td>
                      {TRIM_ORDER.map((tid) => (
                        <td key={tid} className={`py-2.5 px-3 ${tid === trim ? 'bg-[#F7F7F5]' : ''}`}>
                          {TRIM_LINES[tid].climateLabel}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-2.5 pr-3 font-medium text-[#141517]">Sitze & Polster</td>
                      {TRIM_ORDER.map((tid) => (
                        <td key={tid} className={`py-2.5 px-3 ${tid === trim ? 'bg-[#F7F7F5]' : ''}`}>
                          {TRIM_LINES[tid].seatsLabel}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-2.5 pr-3 font-medium text-[#141517]">Räder (Serie)</td>
                      {TRIM_ORDER.map((tid) => (
                        <td key={tid} className={`py-2.5 px-3 ${tid === trim ? 'bg-[#F7F7F5]' : ''}`}>
                          {TRIM_LINES[tid].wheelsLabel}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-2.5 pr-3 font-medium text-[#141517]">Dekorleisten</td>
                      {TRIM_ORDER.map((tid) => (
                        <td key={tid} className={`py-2.5 px-3 ${tid === trim ? 'bg-[#F7F7F5]' : ''}`}>
                          {TRIM_LINES[tid].decorLabel}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-2.5 pr-3 font-medium text-[#141517] align-top">
                        Zusätzliche Serienumfänge
                      </td>
                      {TRIM_ORDER.map((tid) => (
                        <td
                          key={tid}
                          className={`py-2.5 px-3 align-top ${tid === trim ? 'bg-[#F7F7F5]' : ''}`}
                        >
                          <ul className="space-y-1 text-[11px] text-[#4B4F56]">
                            {[
                              ...TRIM_LINES[tid].standardFeatures.sicherheit,
                              ...TRIM_LINES[tid].standardFeatures.komfort,
                            ].map((item) => (
                              <li key={item}>· {item}</li>
                            ))}
                          </ul>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            )}

            {serienTab === 'allgemein' && (
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                <div>
                  <h4 className="font-display font-bold text-[#141517] mb-2">
                    Sicherheit (Allgemeine Serienausstattung)
                  </h4>
                  <ul className="space-y-1.5 text-[#4B4F56]">
                    {GENERAL_STANDARD_EQUIPMENT.sicherheit.map((item) => (
                      <li key={item}>· {item}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-display font-bold text-[#141517] mb-2">
                    Komfort & sonstige Serienausstattung
                  </h4>
                  <ul className="space-y-1.5 text-[#4B4F56]">
                    {GENERAL_STANDARD_EQUIPMENT.komfort.map((item) => (
                      <li key={item}>· {item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}

            {serienTab === 'ecoflex' && (
              <div className="mt-4 text-xs">
                <h4 className="font-display font-bold text-[#141517] mb-2">
                  Serienausstattung der ecoFLEX-Modelle (Seite 11)
                </h4>
                <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[#4B4F56]">
                  {GENERAL_STANDARD_EQUIPMENT.ecoFLEX.map((item) => (
                    <li key={item} className="flex items-start gap-2">
                      <Check className="h-3.5 w-3.5 text-[#D99B00] shrink-0 mt-0.5" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {serienTab === 'awards' && (
              <div className="mt-4 text-xs">
                <p className="text-[#5C6068] mb-3">
                  Der Opel Insignia erhielt bis Juni 2010 insgesamt 40 internationale Auszeichnungen (Seiten 2–3):
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {AWARDS_2009_2010.map((a) => (
                    <div
                      key={a.title}
                      className="flex items-baseline justify-between gap-2 rounded-lg border border-[#F0F1F3] px-3 py-2"
                    >
                      <span className="font-medium text-[#141517]">{a.title}</span>
                      <span className="text-[#5C6068] shrink-0">{a.org}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </section>

      <div className="flex justify-end pt-2">
        <button
          type="button"
          onClick={onNext}
          className="rounded-lg bg-[#141517] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#2A2D32]"
        >
          Weiter zu Motor & Getriebe
        </button>
      </div>
    </div>
  );
};
