import React, { useMemo, useState } from 'react';
import { ENGINES, GENERAL_STANDARD_EQUIPMENT, TRIM_LINES } from '../data/insignia2010';
import { BodyStyleId, EngineSpec, PriceMode, TrimId } from '../types/configurator';
import { formatEuro } from '../utils/configEngine';
import { Check } from 'lucide-react';

interface StepMotorProps {
  bodyStyle: BodyStyleId;
  trim: TrimId;
  engineId: string;
  priceMode: PriceMode;
  onSelectEngine: (engineId: string, switchTrimTo?: TrimId) => void;
  onNext: () => void;
}

type EngineFilter = 'alle' | 'benzin' | 'diesel' | 'ecoflex' | '4x4' | 'automatik';

export const StepMotor: React.FC<StepMotorProps> = ({
  bodyStyle,
  trim,
  engineId,
  priceMode,
  onSelectEngine,
  onNext,
}) => {
  const [filter, setFilter] = useState<EngineFilter>('alle');
  const [showUnavailable, setShowUnavailable] = useState(true);

  const filteredEngines = useMemo(() => {
    return ENGINES.filter((e) => {
      if (filter === 'benzin') return e.fuel === 'benzin';
      if (filter === 'diesel') return e.fuel === 'diesel';
      if (filter === 'ecoflex') return e.isEcoFlex;
      if (filter === '4x4') return e.is4x4;
      if (filter === 'automatik') return e.isAutomatic;
      return true;
    }).filter((e) => (showUnavailable ? true : Boolean(e.prices[bodyStyle]?.[trim])));
  }, [filter, showUnavailable, bodyStyle, trim]);

  const activeEngine = ENGINES.find((e) => e.id === engineId);

  const getFirstAvailableTrim = (engine: EngineSpec): TrimId | null => {
    const order: TrimId[] = ['edition', 'sport', 'innovation', 'selection'];
    for (const tid of order) {
      if (engine.prices[bodyStyle]?.[tid]) return tid;
    }
    return null;
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-bold text-[#141517]">
            03. Motor & Getriebe wählen
          </h2>
          <p className="mt-1 text-sm text-[#5C6068]">
            Alle 18 Motor-Getriebe-Kombinationen (EURO 5) für {TRIM_LINES[trim].name}.
          </p>
        </div>

        <label className="flex items-center gap-2 text-xs text-[#5C6068] cursor-pointer select-none">
          <input
            type="checkbox"
            checked={showUnavailable}
            onChange={(e) => setShowUnavailable(e.target.checked)}
            className="h-4 w-4 rounded border-[#D1D5DB] accent-[#141517]"
          />
          Motoren anderer Linien anzeigen
        </label>
      </div>

      {/* Filter Segmented Control */}
      <div className="flex flex-wrap items-center gap-1 rounded-lg bg-[#EAEBE8] p-1">
        {(
          [
            { id: 'alle', label: 'Alle (18)' },
            { id: 'benzin', label: 'Benzin (9)' },
            { id: 'diesel', label: 'Diesel CDTI (9)' },
            { id: 'ecoflex', label: 'ecoFLEX' },
            { id: '4x4', label: '4x4 Allrad' },
            { id: 'automatik', label: '6-Stufen-Automatik' },
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilter(tab.id)}
            className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
              filter === tab.id
                ? 'bg-white text-[#141517] shadow-xs'
                : 'text-[#5C6068] hover:text-[#141517]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Engine Cards */}
      <div className="grid grid-cols-1 gap-3">
        {filteredEngines.map((engine) => {
          const trimPrice = engine.prices[bodyStyle]?.[trim];
          const isAvailable = Boolean(trimPrice);
          const isSelected = engine.id === engineId && isAvailable;
          const perf =
            bodyStyle === 'tourer' ? engine.performance.tourer : engine.performance.limousine;
          const fallbackTrim = !isAvailable ? getFirstAvailableTrim(engine) : null;

          return (
            <div
              key={engine.id}
              className={`rounded-xl border p-4 transition-all ${
                isSelected
                  ? 'border-[#141517] bg-white ring-1 ring-[#141517]'
                  : isAvailable
                  ? 'border-[#E4E5E7] bg-white hover:border-[#B5B8BE]'
                  : 'border-[#E4E5E7] bg-[#FAFAFA] opacity-75'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-[#5C6068]">
                    <span className="font-medium text-[#141517]">
                      {engine.fuel === 'benzin' ? 'Benzin' : 'Diesel'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{engine.transmission}</span>
                    {engine.isEcoFlex && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span className="font-semibold text-[#15803D]">ecoFLEX</span>
                      </>
                    )}
                    {engine.hasDpf && (
                      <>
                        <span aria-hidden="true">·</span>
                        <span>DPF</span>
                      </>
                    )}
                  </div>

                  <div className="mt-1 flex items-center gap-2">
                    <h3 className="font-display text-base font-bold text-[#141517]">
                      {engine.name}
                    </h3>
                    {isSelected && <Check className="h-4 w-4 text-[#D99B00] shrink-0" />}
                  </div>

                  {engine.availabilityNote && (
                    <p className="mt-1 text-xs text-[#5C6068]">{engine.availabilityNote}</p>
                  )}
                </div>

                <div className="flex sm:flex-col items-center sm:items-end justify-between gap-2 shrink-0">
                  {trimPrice ? (
                    <>
                      <div className="font-mono-tabular text-base font-semibold text-[#141517]">
                        {formatEuro(priceMode === 'brutto' ? trimPrice.brutto : trimPrice.netto)}
                      </div>
                      <button
                        type="button"
                        onClick={() => onSelectEngine(engine.id)}
                        className={`rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                          isSelected
                            ? 'bg-[#141517] text-white'
                            : 'border border-[#141517] bg-white text-[#141517] hover:bg-[#141517] hover:text-white'
                        }`}
                      >
                        {isSelected ? 'Ausgewählt' : 'Motor wählen'}
                      </button>
                    </>
                  ) : fallbackTrim ? (
                    <button
                      type="button"
                      onClick={() => onSelectEngine(engine.id, fallbackTrim)}
                      className="rounded-lg border border-[#DCDEE2] bg-white px-3 py-1.5 text-xs font-medium text-[#141517] hover:bg-[#F2F3F0] transition-colors whitespace-nowrap"
                    >
                      Zu {TRIM_LINES[fallbackTrim].name} wechseln (ab{' '}
                      {formatEuro(
                        priceMode === 'brutto'
                          ? engine.prices[bodyStyle][fallbackTrim]!.brutto
                          : engine.prices[bodyStyle][fallbackTrim]!.netto
                      )}
                      )
                    </button>
                  ) : null}
                </div>
              </div>

              {/* Technical Telemetry Row */}
              <div className="mt-3 pt-3 border-t border-[#F0F1F3] grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                <div>
                  <div className="text-[#5C6068]">Leistung</div>
                  <div className="font-mono-tabular font-medium text-[#141517]">
                    {engine.kw} kW ({engine.ps} PS)
                  </div>
                </div>
                <div>
                  <div className="text-[#5C6068]">Drehmoment</div>
                  <div className="font-mono-tabular font-medium text-[#141517]">
                    {engine.torqueNm} Nm
                    {engine.overboostNm ? ` (${engine.overboostNm} Overb.)` : ''}
                  </div>
                </div>
                <div>
                  <div className="text-[#5C6068]">0–100 km/h / Vmax</div>
                  <div className="font-mono-tabular font-medium text-[#141517]">
                    {perf.accel0100.toFixed(1).replace('.', ',')} s · {perf.topSpeedKmh} km/h
                  </div>
                </div>
                <div>
                  <div className="text-[#5C6068]">Verbrauch komb.</div>
                  <div className="font-mono-tabular font-medium text-[#141517]">
                    {perf.consumptionCombined.toFixed(1).replace('.', ',')} l/100km
                  </div>
                </div>
                <div>
                  <div className="text-[#5C6068]">CO₂ / Anhängelast 12%</div>
                  <div className="font-mono-tabular font-medium text-[#141517]">
                    {perf.co2Combined} g/km ·{' '}
                    {bodyStyle === 'tourer' ? engine.towing.tourer12Percent : engine.towing.limo12Percent}{' '}
                    kg
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ecoFLEX specific notice when selected */}
      {activeEngine?.isEcoFlex && (
        <div className="rounded-xl border border-[#D1FAE5] bg-[#F0FDF4] p-4 text-xs text-[#14532D]">
          <div className="font-display font-bold text-sm mb-1.5">
            Enthaltene ecoFLEX-Serienausstattung (Seite 11)
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
            {GENERAL_STANDARD_EQUIPMENT.ecoFLEX.map((item) => (
              <div key={item}>· {item}</div>
            ))}
          </div>
        </div>
      )}

      <div className="flex justify-end pt-2">
        <button
          type="button"
          onClick={onNext}
          className="rounded-lg bg-[#141517] px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-[#2A2D32]"
        >
          Weiter zu Exterieur, Sitzen & Rädern
        </button>
      </div>
    </div>
  );
};
