import React from 'react';
import { ConfigStep } from '../types/configurator';

interface HeaderProps {
  activeStep: ConfigStep;
  onSelectStep: (step: ConfigStep) => void;
}

const NAV_STEPS: { id: ConfigStep; label: string }[] = [
  { id: 'karosserie', label: 'Karosserie & Linie' },
  { id: 'motor', label: 'Motor' },
  { id: 'exterieur', label: 'Exterieur & Räder' },
  { id: 'extras', label: 'Sonderausstattung' },
  { id: 'zusammenfassung', label: 'Mein Insignia' },
];

export const Header: React.FC<HeaderProps> = ({ activeStep, onSelectStep }) => {
  return (
    <header className="no-print sticky top-0 z-40 border-b border-[#E4E5E7] bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
        <button
          type="button"
          onClick={() => onSelectStep('karosserie')}
          className="font-display text-lg font-bold tracking-tight text-[#141517] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#141517]"
        >
          Opel Insignia Konfigurator
        </button>

        <nav
          aria-label="Konfigurationsschritte"
          className="hidden md:flex items-center gap-6 overflow-x-auto"
        >
          {NAV_STEPS.map((step) => {
            const isActive = activeStep === step.id;
            return (
              <button
                key={step.id}
                type="button"
                onClick={() => onSelectStep(step.id)}
                className={`relative py-5 text-sm font-medium transition-colors whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#141517] ${
                  isActive
                    ? 'text-[#141517] font-semibold'
                    : 'text-[#5C6068] hover:text-[#141517]'
                }`}
              >
                {step.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className="absolute inset-x-0 bottom-0 h-0.5 bg-[#D99B00]"
                  />
                )}
              </button>
            );
          })}
        </nav>

        <button
          type="button"
          onClick={() => onSelectStep('zusammenfassung')}
          className="rounded-lg bg-[#141517] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#2A2D32] whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#141517]"
        >
          Zusammenfassung
        </button>
      </div>
    </header>
  );
};
