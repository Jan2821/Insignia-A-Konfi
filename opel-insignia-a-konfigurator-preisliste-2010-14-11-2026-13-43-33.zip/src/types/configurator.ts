export type BodyStyleId = 'limo4' | 'limo5' | 'tourer';
export type TrimId = 'selection' | 'edition' | 'sport' | 'innovation';
export type FuelType = 'benzin' | 'diesel';
export type PriceMode = 'brutto' | 'netto';
export type StudioView = 'exterior' | 'interior' | 'dimensions';
export type ConfigStep = 'karosserie' | 'motor' | 'exterieur' | 'extras' | 'zusammenfassung';

export interface PricePair {
  brutto: number;
  netto: number;
}

export interface BodyStyleSpec {
  id: BodyStyleId;
  name: string;
  shortName: string;
  subtitle: string;
  description: string;
  lengthMm: number;
  widthWithMirrorsMm: number;
  widthWithoutMirrorsMm: number;
  heightMm: number;
  wheelbaseMm: number;
  trackFrontMm: number;
  trackRearMm: number;
  turningCircleWallM: number;
  turningCircleCurbM: number;
  cargoLengthToRearSeatMm: number;
  cargoLengthFoldedMm: number;
  cargoWidthWheelhouseMm: number;
  cargoWidthMaxMm: number;
  trunkVolumeStandardL: number;
  trunkVolumeFoldedWindowL: number;
  trunkVolumeFoldedRoofL: number | null;
  curbWeightKg: number;
  grossWeightKg: number;
  payloadKg: number;
  axleLoadFrontKg: number;
  axleLoadRearKg: number;
  roofLoadKg: number;
}

export interface TrimLineInfo {
  id: TrimId;
  name: string;
  tagline: string;
  highlights: string[];
  standardFeatures: {
    sicherheit: string[];
    infotainment: string[];
    komfort: string[];
  };
  wheelsLabel: string;
  seatsLabel: string;
  climateLabel: string;
  infotainmentLabel: string;
  decorLabel: string;
}

export interface EngineSpec {
  id: string;
  name: string;
  fuel: FuelType;
  isEcoFlex: boolean;
  hasDpf: boolean;
  transmission: string;
  isAutomatic: boolean;
  is4x4: boolean;
  kw: number;
  ps: number;
  rpmPower: number;
  cylinders: number;
  displacementCc: number;
  torqueNm: number;
  torqueRpm: string;
  overboostNm?: number;
  emissionStandard: string;
  fuelLabel: string;
  tankLiters: number;
  availabilityNote?: string;
  prices: Record<BodyStyleId, Partial<Record<TrimId, PricePair>>>;
  performance: {
    limousine: {
      topSpeedKmh: number;
      topSpeedLimited?: boolean;
      accel0100: number;
      consumptionUrban: number;
      consumptionExtra: number;
      consumptionCombined: number;
      co2Urban: number;
      co2Extra: number;
      co2Combined: number;
    };
    tourer: {
      topSpeedKmh: number;
      topSpeedLimited?: boolean;
      accel0100: number;
      consumptionUrban: number;
      consumptionExtra: number;
      consumptionCombined: number;
      co2Urban: number;
      co2Extra: number;
      co2Combined: number;
    };
  };
  towing: {
    limoUnbraked: number;
    limo10Percent: string;
    limo12Percent: string;
    tourerUnbraked: number;
    tourer8Percent: string;
    tourer10Percent: string;
    tourer12Percent: string;
  };
}

export interface PaintColor {
  id: string;
  name: string;
  type: 'Uni' | 'Zweischicht-Metallic' | 'Perleffekt' | 'Mineraleffekt';
  hex: string;
  accentHex: string;
  price: PricePair;
  code: string;
}

export interface SeatPackageOption {
  id: string;
  code: string;
  name: string;
  subtitle: string;
  details: string[];
  hasLeather: boolean;
  hasBeigeOption: boolean;
  beigeAllowedOnSport: boolean;
  hasAgrDriver: boolean;
  hasAgrPassenger: boolean;
  includesOpcInterior: boolean;
  includedWheelInches?: 18 | 19 | 20;
  requiresSichtPaket?: boolean;
  isPremiumPackage?: boolean;
  prices: Partial<Record<TrimId, PricePair>>;
}

export interface WheelOption {
  id: string;
  code: string;
  name: string;
  sizeInches: 16 | 17 | 18 | 19 | 20;
  tireSpec: string;
  description: string;
  standardOn?: TrimId[];
  prices: Partial<Record<TrimId, PricePair | 'SERIE' | 'OHNE_MEHRPREIS'>>;
  note?: string;
}

export type OptionCategoryId =
  | 'pakete'
  | 'innovationen'
  | 'sicherheit'
  | 'infotainment'
  | 'komfort'
  | 'garantie';

export interface ConfigOption {
  id: string;
  code: string;
  category: OptionCategoryId;
  name: string;
  description: string;
  details?: string[];
  paketBestandteil?: string;
  bodyStyles?: BodyStyleId[];
  prices: Partial<Record<TrimId, PricePair | 'SERIE' | 'OHNE_MEHRPREIS'>>;
  mutuallyExclusiveGroup?: string;
  footnote?: string;
}

export interface AccessoryItem {
  id: string;
  orderKey: string;
  category: 'Trägersysteme' | 'Schutz & Matten' | 'Kindersicherheit' | 'Räder & Winter' | 'Sicherheit & Laderaum';
  name: string;
  description?: string;
  price: PricePair;
  availableTrims: TrimId[];
  bodyStyles?: BodyStyleId[];
  engineFilter?: string[];
}

export interface ConfigurationState {
  bodyStyle: BodyStyleId;
  trim: TrimId;
  engineId: string;
  paintId: string;
  seatPackageId: string;
  interiorColor: 'Schwarz' | 'Beige' | 'Indian Summer (Cognac)';
  decorId: 'titanium' | 'titanium_oliv' | 'klavierlack' | 'kibo_holz';
  wheelId: string;
  infotainmentId: 'UZZ' | 'UXW' | 'UXX';
  phonePrepId: string | null;
  warrantyId: string | null;
  selectedOptionIds: string[];
  selectedAccessoryIds: string[];
}

export interface LineItem {
  id: string;
  code: string;
  label: string;
  category: string;
  brutto: number;
  netto: number;
  note?: string;
}

export interface ValidationNotice {
  id: string;
  type: 'info' | 'warning' | 'action';
  message: string;
  actionLabel?: string;
  onFix?: () => void;
}

export interface SavedBuild {
  id: string;
  name: string;
  createdAt: string;
  totalBrutto: number;
  totalNetto: number;
  summaryTitle: string;
  config: ConfigurationState;
}
